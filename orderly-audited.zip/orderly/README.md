# Orderly

> Messy WhatsApp orders in Telugu + English (text or voice notes) become a clean, **verified** order list.
> Runs entirely on your computer with open-weight models. Built for a relative's small shop.

Customers send things like *"namaste anna, 2 kg biyyam and 1 kg pappu pampandi"*, *"oil kuda ivvandi"* or a
30-second voice note. Orderly turns that into a list, prices what is clear, and **asks about what isn't**,
with a ready-to-send question in English and Telugu ("Chilli Powder: which size? (100g / 250g)").

## The design rule: the model reads, code decides

| Step | Who does it | Tool |
|---|---|---|
| Voice note to text | open-weight speech model | [faster-whisper](https://github.com/SYSTRAN/faster-whisper) (Whisper), biased with the shop's own product names |
| Messages to structured items | open-weight LLM, JSON-schema constrained | [Ollama](https://ollama.com) + Gemma 3 (swappable) |
| Is it a real product? Which size? Which unit? Is 500 kg plausible? Price? | **plain code** | `catalog.py`, `validate.py` |
| Unsure about anything | **flag + question for the customer**, never a guess | `report.py` |

The model cannot invent a product, a price or a quantity: every line is checked against the shop's catalog,
and anything doubtful is marked **ASK** and left out of the confirmed total.

## Quick start

```bash
# 1. local models
ollama pull gemma3:4b            # or gemma3:12b if your laptop can take it (better Telugu)
pip install -e ".[voice]"        # voice = faster-whisper (optional; text-only needs no packages)

# 2. try the sample catalog (no customer data needed)
orderly run --chat data/sample_chat.txt --owner "Shop"

# 3. the web UI (http://127.0.0.1:8000, bound to this computer only)
orderly serve --whisper-model small
```

No install? `PYTHONPATH=src python -m orderly ...` works too (Python 3.9+, standard library only for text mode).

### Use it for a real shop
1. Copy `data/catalog.sample.json` to `catalog.real.json`; put in the shop's real items, prices, and the words customers use (Telugu script **and** transliterations). Products sold in sizes use `"variants"`.
2. In WhatsApp: open the chat, **Export chat, Include media**. Unzip; pass the `.txt` as `--chat` and the folder as `--audio-dir`.
3. `orderly --catalog catalog.real.json run --chat chat.txt --audio-dir media/ --owner "<shop's name in chat>"`

## Measure it (for your write-up)

Label 20 or so real messages in `data/eval_cases.jsonl` format, then:

```bash
orderly eval --cases data/eval_cases.jsonl
```

Every case needs exactly one `"expected_status"`: `CONFIRMED` or `NEEDS_REVIEW` (no other value; `load_cases`
rejects anything else). Write it from the ORIGINAL customer message, never from what the model returned.

| Expected | Actual | Result |
| --- | --- | --- |
| CONFIRMED | CONFIRMED, order exactly as `expected` | PASS |
| CONFIRMED | CONFIRMED, order differs (missing/extra/wrong item) | **FAIL - wrong confirmed order (P0)** |
| CONFIRMED | NEEDS_REVIEW | FAIL - false rejection (usability, not safety) |
| NEEDS_REVIEW | NEEDS_REVIEW | PASS - safely blocked |
| NEEDS_REVIEW | CONFIRMED | **FAIL - FALSE CONFIRMATION (P0)** |
| any | exception | FAIL - execution failure (no order exists, so nothing was confirmed) |

It reports three separate numbers (A valid-order confirmation accuracy, B unsafe-order blocking accuracy,
C false-confirmation rate, target 0), lists every P0, and ends with an `AUDIT RESULT` block with two independent
fields: **AUDIT STATUS** (COMPLETED, or STOPPED because the real model is unavailable, its provenance is
unverified, or a P0 was found) and **READINESS** (NOT ASSESSED / NOT READY / DEMO-CONTROLLED REVIEW ONLY - KNOWN P1
LIMITATION / DEMO-CONTROLLED REVIEW READY). A P0 is a demonstrated unsafe CONFIRMED; a P1 is a known limitation that
does not stop the audit but caps readiness. It never says "production ready". Exit code: 1 on P0, 2 if stopped.
Pass `--expect-digest <sha256>` to let provenance reach VERIFIED.

### Counting cases (terminology)

Every case in the audit scope ("required") ends in exactly one **execution classification**:

| Classification | Meaning | Evaluation outcome |
| --- | --- | --- |
| **Valid** | the case ran to a result | PASS, FAIL or P0 |
| **Failed** | execution failed (e.g. Ollama timeout) | none |
| **Skipped** | execution never started | none |

```text
Required  = Valid + Failed + Skipped
Attempted = Valid + Failed
P0 <= Valid
```

"Valid case" means only this: *a case that produces a valid evaluation result (PASS, FAIL or P0)*. It does **not**
mean a correct customer order, a safe case, a case expected to be `CONFIRMED`, a case that passed, or a case that
merely started. A valid case can be a FAIL or a P0. Use **Valid** for the classification, **PASS / FAIL / P0** for
the outcome, **Failed** for execution failure, **Skipped** for never started, and always write **P0** (never "PO").
Skipped cases are never counted as P0s.

**Worked example (run-to-completion).** 10 required cases: 1 PASS, 2 FAIL, 3 P0, 4 PASS, 5 Ollama timeout,
6 PASS, 7-10 never started.

```text
Required cases: 10    Attempted cases: 6    Valid cases: 5    Failed cases: 1    Skipped cases: 4
P0 false confirmations: 1
Attempted = Valid + Failed          6 = 5 + 1
Required  = Valid + Failed + Skipped   10 = 5 + 1 + 4
P0 <= Valid                          1 <= 5
```

**Worked example (stop at the first P0, sequential).** Case 1 PASS, case 2 PASS, case 3 P0, cases 4-10 skipped.

```text
Required cases: 10    Attempted cases: 3    Valid cases: 3    Failed cases: 0    Skipped cases: 7
P0 false confirmations: 1      (the 7 skipped cases are not P0s)
AUDIT STATUS: STOPPED - P0 FALSE CONFIRMATION FOUND      READINESS: NOT READY
```

**What `orderly eval` reports today (documentation of current behaviour, not a change to it).**
`orderly eval` runs every case and does not stop at the first P0; the `cases:` line is the *Attempted* count
(Valid + Failed), and `execution failures` is the *Failed* count, so Valid = `cases` - `execution failures`.
It does not count Skipped or print Required: cases that never start (for example after Ctrl+C) simply do not
appear. The stop-at-first-P0 example above is therefore the target counting rule, not what the current evaluator
does.

Run it against the real model (`ollama` running) to get real-model numbers; with a fake extractor it only tests
the deterministic gate.

## Why open-weight models matter here

- **Privacy:** customer names, addresses and buying habits never leave the shop's computer.
- **Cost:** no per-message API bill for a shop with thin margins.
- **Control:** the catalog's words are fed to both Whisper and the LLM, and any model can be swapped (`--model`, `--whisper-model`).
- **Works offline** once models are downloaded.

## Known limits (honest list)

- Telugu quality depends on model size. Voice notes are the hardest part: use `--whisper-model medium` or larger if the machine allows, and check results on real recordings.
- Whisper confidence is a rough signal; unclear audio is marked and the order carries a warning instead of silently guessing.
- Telugu question templates are short and should be reviewed by a native speaker (`validate.py`).
- Prices in the sample catalog are made up.
- A customer's later correction ("actually 3 kg") is handled by the LLM, and every line of an order that contains a correction asks for a final confirmation. Lines heard in voice notes always ask too.
- Every quantity, unit and size the LLM returns must literally appear in the customer's messages, but the check is per order, not per item (a swapped pair of numbers can pass), and items the LLM leaves out are only caught heuristically (`coverage.py`: a catalog product named in the text with no line, or more item-like segments than lines, makes the order NEEDS_REVIEW). Completeness cannot be proven: an unknown product written without a unit or separator is invisible to it.
- Image attachments (photos of handwritten lists) are ignored for now.
- Windows/macOS/Linux: pure Python, but `faster-whisper` needs its own wheels.

## Tests

```bash
PYTHONPATH=src:tests python -m unittest discover -s tests -v     # 124 tests, no models needed
```
Tests use a scripted fake LLM and fake speech model, so they cover parsing, validation, pricing, the web API and
the Ollama request format, but **not** real model quality. That is what `orderly eval` is for.

## Contributing

Ideas that would help: more Telugu/Hindi/Tamil aliases and number words, reviewed question templates,
photo-of-handwritten-list input (vision model), a WhatsApp Business API hook, a printable order slip.
