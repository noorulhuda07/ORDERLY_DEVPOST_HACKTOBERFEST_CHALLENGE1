"""Customer-item OMISSION: the customer asked for N items, the extractor returned fewer.

test_safety.test_item_not_in_the_message_is_not_confirmed covers the opposite failure (an EXTRA, invented item
that is not in the text). Here an item that IS in the text silently disappears during extraction. Every such
order must end as NEEDS_REVIEW with a warning naming the problem, never CONFIRMED."""
import unittest

from fakes import FakeExtractor, item
from helpers import catalog
from orderly import evaluate
from orderly.chat import Message
from orderly.extract import RawOrder
from orderly.pipeline import build_order

C = catalog()
RICE = item("rice", "Rice", 2, "kg")
SUGAR = item("sugar", "Sugar", 1, "kg")
OIL1L = item("sunflower oil", "Sunflower Oil", 1, "litre")


def run(texts, *items):
    texts = [texts] if isinstance(texts, str) else texts
    return build_order("Cust", [Message("Cust", t) for t in texts], C, FakeExtractor(default=RawOrder(None, list(items))))


def omission_warned(o):
    return any("Possible missing item" in w for w in o.warnings)


class OmissionTests(unittest.TestCase):
    def assertBlocked(self, o):
        self.assertEqual(o.status, "NEEDS_REVIEW")
        self.assertTrue(omission_warned(o), o.warnings)

    def test_01_two_items_one_returned(self):
        self.assertBlocked(run("2 kg rice and 5 litres sunflower oil", RICE))

    def test_02_three_items_two_returned(self):
        self.assertBlocked(run("2 kg rice, 1 litre sunflower oil and 1 kg sugar", RICE, OIL1L))

    def test_03_middle_item_omitted(self):
        self.assertBlocked(run("2 kg rice, 1 kg sugar, 1 litre sunflower oil", RICE, OIL1L))
        # the literal wording from the audit request ("oil" is ambiguous, so the line itself also asks)
        o = run("2 kg rice, 1 kg sugar, 1 litre oil", RICE, item("oil", "oil", 1, "litre"))
        self.assertBlocked(o)

    def test_04_last_item_omitted(self):
        self.assertBlocked(run("2 kg rice and 1 litre sunflower oil", RICE))

    def test_05_same_product_two_sizes_one_line(self):
        self.assertBlocked(run("1 litre sunflower oil and 500 ml sunflower oil", OIL1L))
        self.assertBlocked(run("1 litre oil and 500 ml oil", item("oil", "Sunflower Oil", 1, "litre")))

    def test_06_correction_and_omitted_item(self):
        self.assertBlocked(run("5 kg sugar, actually make it 3 kg, and 2 litres sunflower oil", item("sugar", "Sugar", 3, "kg")))

    def test_07_telugu_english_mixed(self):
        rice, sugar = item("బియ్యం", "Rice", 1, "kg"), item("పంచదార", "Sugar", 0.5, "kg")
        self.assertBlocked(run("ఒక కిలో బియ్యం, అర కిలో పంచదార, రెండు లీటర్లు పల్లీ నూనె", rice, sugar))
        self.assertBlocked(run(["namaste anna", "ఒక కిలో బియ్యం and 1 kg pappu"], rice))

    def test_08_and_also(self):
        self.assertBlocked(run("2 kg rice. And also 1 litre sunflower oil.", RICE))

    def test_09_long_message_with_unrelated_text(self):
        text = ("Hello anna, I hope you are doing well. Please deliver before 6 pm to flat 12, near the temple. "
                "2 kg rice, 1 kg sugar and 1 litre sunflower oil please. Call me on 9876543210 if needed. Thanks!")
        self.assertBlocked(run(text, RICE, SUGAR))

    def test_item_without_a_number_is_still_noticed(self):
        self.assertBlocked(run("2 kg rice and sabbu", RICE))

    def test_two_items_without_separator(self):
        self.assertBlocked(run("2 kg rice 1 kg sugar", RICE))

    def test_item_spread_over_two_messages(self):
        self.assertBlocked(run(["2 kg rice", "1 litre sunflower oil"], RICE))

    def test_product_named_in_unrelated_text_fails_closed(self):
        self.assertBlocked(run("I don't need sugar this time. 2 kg rice", RICE))

    def test_nothing_extracted_still_blocks(self):
        o = run("2 kg rice and 1 kg sugar")
        self.assertEqual(o.status, "NEEDS_REVIEW")


class NoFalseAlarmTests(unittest.TestCase):
    """The check must not make normal, complete orders unusable."""

    def test_complete_orders_still_confirm(self):
        for text, items in [
            ("2 kg rice and 1 litre sunflower oil", [RICE, OIL1L]),
            ("2 kg rice. And also 1 litre sunflower oil.", [RICE, OIL1L]),
            ("2 kg rice, 1 kg sugar, 1 litre sunflower oil", [RICE, SUGAR, OIL1L]),
            ("1.5 kg rice", [item("rice", "Rice", 1.5, "kg")]),
        ]:
            o = run(text, *items)
            self.assertEqual((o.status, o.warnings), ("CONFIRMED", []), text)

    def test_long_message_with_all_items_confirms(self):
        text = ("Hello anna, I hope you are doing well. Please deliver before 6 pm to flat 12, near the temple. "
                "2 kg rice, 1 kg sugar and 1 litre sunflower oil please. Call me on 9876543210 if needed. Thanks!")
        o = run(text, RICE, SUGAR, OIL1L)
        self.assertEqual((o.status, o.warnings), ("CONFIRMED", []))

    def test_telugu_complete_order_confirms(self):
        o = run("ఒక కిలో ఉల్లిపాయలు, అర కిలో టమాటా", item("ఉల్లిపాయలు", "Onion", 1, "kg"), item("టమాటా", "Tomato", 0.5, "kg"))
        self.assertEqual(o.status, "CONFIRMED")

    def test_one_line_covering_one_item_is_not_a_false_alarm(self):
        o = run("2 packet tea powder 250g", item("tea powder", "Tea Powder", 2, "packet", "250g"))
        self.assertEqual(o.warnings, [])


class KnownLimitation(unittest.TestCase):
    @unittest.expectedFailure
    def test_unknown_product_without_unit_or_separator_cannot_be_detected(self):
        """Completeness is not provable: a product the catalog has never heard of, with no unit and no separator,
        looks like ordinary words. Documented limitation; the shopkeeper review step remains necessary."""
        o = run("2 kg rice oka bellam", RICE)            # 'bellam' (jaggery) is not in the catalog
        self.assertEqual(o.status, "NEEDS_REVIEW")


class EvalOmissionTests(unittest.TestCase):
    def test_eval_counts_a_confirmed_order_with_missing_items_as_a_false_confirmation(self):
        cases = [{"messages": ["2 kg rice oka bellam"],
                  "expected": [{"product": "rice", "quantity": 2}, {"product": "bellam", "quantity": 1}],
                  "expected_flags": []}]
        r = evaluate.run_eval(cases, C, FakeExtractor(default=RawOrder(None, [RICE])))
        self.assertEqual(r.false_confirmations, 1)
        self.assertIn("MISSING ITEMS", r.failures[0])

    def test_eval_does_not_flag_blocked_omissions(self):
        cases = [{"messages": ["2 kg rice and 1 kg sugar"],
                  "expected": [{"product": "rice", "quantity": 2}, {"product": "sugar", "quantity": 1}],
                  "expected_flags": []}]
        r = evaluate.run_eval(cases, C, FakeExtractor(default=RawOrder(None, [RICE])))
        self.assertEqual(r.false_confirmations, 0)


if __name__ == "__main__":
    unittest.main()
