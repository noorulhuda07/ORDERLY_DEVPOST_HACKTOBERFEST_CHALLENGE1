"""The shop's product catalog and fuzzy product matching. Code, not the model, decides what exists."""
import difflib
import json
import string
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .units import normalize_size

_PUNCT = {ord(c): " " for c in string.punctuation}
_INVISIBLE = {0x200C: None, 0x200D: None, 0x200E: None, 0x200F: None}


def norm(s: str) -> str:
    """Lowercase, drop punctuation and invisible marks (keeps Telugu vowel signs), collapse spaces."""
    s = s.translate(_INVISIBLE).lower().translate(_PUNCT)
    return " ".join(s.split())


@dataclass
class Product:
    id: str
    name: str
    unit: str = "kg"                      # base unit: kg, l, pcs, packet
    price: float = 0.0                    # price per base unit (ignored when variants exist)
    aliases: List[str] = field(default_factory=list)
    variants: Dict[str, float] = field(default_factory=dict)   # size label -> price per piece
    max_qty: float = 50.0

    @property
    def names(self) -> List[str]:
        return [self.name] + list(self.aliases)

    def variant_key(self, size: Optional[str]) -> Optional[str]:
        want = normalize_size(size)
        for k in self.variants:
            if normalize_size(k) == want and want is not None:
                return k
        return None


def _check_product(p: "Product") -> None:
    """A mistyped catalog must fail loudly at load time, not confirm a Rs 0 line later."""
    if p.unit not in ("kg", "l", "pcs", "packet"):
        raise ValueError(f"product {p.id}: unit must be kg, l, pcs or packet (got {p.unit!r})")
    if not (0 < p.max_qty < float("inf")):
        raise ValueError(f"product {p.id}: max_qty must be a finite number > 0")
    if p.variants:
        seen = set()
        for label, price in p.variants.items():
            n = normalize_size(label)
            if n is None or n in seen:
                raise ValueError(f"product {p.id}: bad or duplicate size {label!r}")
            seen.add(n)
            if not (0 < price < float("inf")):
                raise ValueError(f"product {p.id}: size {label!r} needs a finite price > 0")
    elif not (0 < p.price < float("inf")):
        raise ValueError(f"product {p.id}: price must be > 0 (or give sizes in 'variants')")


@dataclass
class Match:
    status: str                           # exact | fuzzy | ambiguous | none
    product: Optional[Product] = None
    candidates: List[Product] = field(default_factory=list)
    score: float = 0.0


class Catalog:
    def __init__(self, products: List[Product], shop: str = "", currency: str = "₹"):
        if not products:
            raise ValueError("catalog has no products")
        ids = [p.id for p in products]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate product ids in catalog")
        for p in products:
            _check_product(p)
        self.products, self.shop, self.currency = products, shop, currency
        self._names = {p.id: [n for n in (norm(x) for x in p.names) if n] for p in products}

    @classmethod
    def from_dict(cls, data: dict) -> "Catalog":
        try:
            prods = [Product(id=p["id"], name=p["name"], unit=p.get("unit", "kg"), price=float(p.get("price", 0)),
                             aliases=list(p.get("aliases", [])), variants=dict(p.get("variants", {})),
                             max_qty=float(p.get("max_qty", 50))) for p in data["products"]]
        except (KeyError, TypeError, AttributeError) as e:
            raise ValueError(f"malformed catalog: {e!r}") from e
        return cls(prods, data.get("shop", ""), data.get("currency", "₹"))

    @classmethod
    def load(cls, path: str) -> "Catalog":
        with open(path, encoding="utf-8") as f:
            return cls.from_dict(json.load(f))

    def match(self, text: str) -> Match:
        q = norm(text or "")
        if not q:
            return Match("none")
        qt = set(q.split())
        scored = []
        for p in self.products:
            best = 0.0
            for n in self._names[p.id]:
                if q == n:
                    s = 1.0
                else:
                    nt = set(n.split())
                    s = 0.9 if (qt <= nt or nt <= qt) else difflib.SequenceMatcher(None, q, n).ratio()
                best = max(best, s)
            scored.append((best, p))
        scored.sort(key=lambda x: -x[0])
        top = scored[0][0]
        if top < 0.8:
            return Match("none", score=top)
        close = [p for s, p in scored if s >= top - 0.05]
        if len(close) > 1:
            return Match("ambiguous", candidates=close, score=top)
        return Match("exact" if top >= 1.0 else "fuzzy", product=close[0], score=top)

    def prompt_lines(self) -> str:
        out = []
        for p in self.products:
            extra = f"; sizes: {', '.join(p.variants)}" if p.variants else f"; sold per {p.unit}"
            al = f" (also called: {', '.join(p.aliases)})" if p.aliases else ""
            out.append(f"- {p.name}{al}{extra}")
        return "\n".join(out)

    def whisper_hint(self, limit: int = 40) -> str:
        """Every product's own name first (so none is left out), then aliases round-robin."""
        words: List[str] = [p.name for p in self.products]
        depth = 0
        while len(words) < limit and any(len(p.aliases) > depth for p in self.products):
            words += [p.aliases[depth] for p in self.products if len(p.aliases) > depth]
            depth += 1
        return "Grocery order: " + ", ".join(words[:max(limit, len(self.products))])
