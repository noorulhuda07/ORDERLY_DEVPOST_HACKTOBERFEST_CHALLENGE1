"""Voice notes -> text with an open-weight Whisper model (faster-whisper, runs locally).

The shop's product names are passed as an initial prompt, which biases Whisper toward the
words that actually occur in orders (biyyam, pappu, ...).
"""
import os
from typing import List, Optional, Tuple

from .chat import MISSING, UNCLEAR, Message, with_text


class TranscribeError(RuntimeError):
    pass


class Transcriber:
    def transcribe(self, path: str) -> Tuple[str, bool]:  # pragma: no cover - interface
        """Return (text, low_confidence)."""
        raise NotImplementedError


class FasterWhisperTranscriber(Transcriber):
    def __init__(self, model_size: str = "small", language: Optional[str] = None,
                 initial_prompt: Optional[str] = None, device: str = "auto", compute_type: str = "int8"):
        self.model_size, self.language, self.initial_prompt = model_size, language, initial_prompt
        self.device, self.compute_type = device, compute_type
        self._model = None

    def _load(self):
        if self._model is None:
            try:
                from faster_whisper import WhisperModel
            except ImportError as e:
                raise TranscribeError("faster-whisper is not installed: pip install faster-whisper") from e
            self._model = WhisperModel(self.model_size, device=self.device, compute_type=self.compute_type)
        return self._model

    def transcribe(self, path: str) -> Tuple[str, bool]:
        try:
            segments, _info = self._load().transcribe(path, language=self.language, beam_size=5,
                                                      vad_filter=True, initial_prompt=self.initial_prompt)
            segs = list(segments)
        except TranscribeError:
            raise
        except Exception as e:
            raise TranscribeError(f"could not transcribe {os.path.basename(path)}: {e}") from e
        text = " ".join(s.text.strip() for s in segs).strip()
        if not segs:
            return "", True
        avg = sum(s.avg_logprob for s in segs) / len(segs)
        return text, avg < -1.0


def resolve_audio(messages: List[Message], audio_dir: Optional[str], transcriber: Optional[Transcriber]) -> List[Message]:
    """Replace audio messages by their transcripts. Problems are marked in the text, never hidden."""
    out = []
    for m in messages:
        if m.kind != "audio":
            out.append(m)
            continue
        # the file name comes from chat text (untrusted): keep only its base name so it cannot leave audio_dir
        name = os.path.basename((m.attachment or "").replace("\\", "/"))
        path = os.path.join(audio_dir, name) if audio_dir and name else None
        if not path or not os.path.isfile(path) or transcriber is None:
            out.append(with_text(m, f"{MISSING} {m.attachment}"))
            continue
        try:
            text, low = transcriber.transcribe(path)
        except TranscribeError as e:
            out.append(with_text(m, f"{UNCLEAR} ({e})"))
            continue
        out.append(with_text(m, f"{text} {UNCLEAR}" if low or not text else text))
    return out
