"""Measure the pipeline on real messages you label yourself. Gives you numbers for the write-up.

cases.jsonl, one JSON object per line:
  {"messages": ["2 kg biyyam", "oil kuda"],
   "expected": [{"product": "rice", "quantity": 2, "size": null}],
   "expected_flags": ["ambiguous_product"]}
quantity is in the product's base unit (kg / l / pcs). size is e.g. "1l" or null.

EVERY case has exactly ONE expected final status, written by a human from the ORIGINAL customer message (never
from the model's output):  "expected_status": "CONFIRMED" | "NEEDS_REVIEW"  (no other value exists).
  CONFIRMED     the request is clear and complete and the catalog supports it: the order may be created.
  NEEDS_REVIEW  anything unclear, incomplete, contradictory, unsupported, misheard or manipulated.
`expected` lists the items a perfect reader would extract (final values after corrections/cancellations).
Optional "voice": [0, 2] marks those message indexes as speech-to-text (voice always needs review).

Pass/fail (case level):
  CONFIRMED    + CONFIRMED and the order matches `expected` exactly   PASS
  CONFIRMED    + CONFIRMED but the order differs from `expected`      FAIL - WRONG CONFIRMED ORDER (P0)
  CONFIRMED    + NEEDS_REVIEW                                         FAIL - false rejection (usability)
  NEEDS_REVIEW + NEEDS_REVIEW                                         PASS - safely blocked
  NEEDS_REVIEW + CONFIRMED                                            FAIL - FALSE CONFIRMATION (P0)
  any          + exception                                            FAIL - execution failure (fails closed)
AUDIT STATUS (may the audit continue?) and READINESS (may it be used?) are separate; see audit_result().

An expected item may carry "confirm": true/false = may / must NOT be CONFIRMED. Default: true when the case
expects no flags, false when it does. The number that matters most is the FALSE CONFIRMATION RATE: confirmed
lines that are not an expected, confirmable item, plus any order that is CONFIRMED while expected items are missing.
"""
import json
from collections import Counter
from dataclasses import dataclass, field
from typing import List

from .catalog import Catalog
from .chat import Message
from .extract import Extractor
from .pipeline import build_order


@dataclass
class EvalResult:
    cases: int = 0
    expected_items: int = 0
    found_items: int = 0
    correct_items: int = 0
    expected_flags: int = 0
    found_flags: int = 0
    extra_flags: int = 0
    confirmed_items: int = 0
    false_confirmations: int = 0
    missed_confirms: int = 0
    failures: List[str] = field(default_factory=list)
    # ---- case-level status accounting (the numbers that matter) ----
    confirm_cases: int = 0                 # cases whose expected_status is CONFIRMED
    review_cases: int = 0                  # cases whose expected_status is NEEDS_REVIEW
    correctly_confirmed: int = 0           # expected CONFIRMED, got CONFIRMED, order content exactly right
    false_rejections: int = 0              # expected CONFIRMED, got NEEDS_REVIEW (usability, not safety)
    correctly_blocked: int = 0             # expected NEEDS_REVIEW, got NEEDS_REVIEW
    false_confirmed_cases: int = 0         # expected NEEDS_REVIEW, got CONFIRMED            -> P0
    wrong_confirmed_cases: int = 0         # expected CONFIRMED, got CONFIRMED but order wrong -> P0
    execution_failures: int = 0            # exception while processing (cannot have been CONFIRMED)
    inferred_status_cases: int = 0         # cases that lacked expected_status (only possible via run_eval, never load_cases)
    p0: List[str] = field(default_factory=list)
    rejections: List[str] = field(default_factory=list)      # false-rejection notes (usability, not safety)

    @property
    def valid_confirmation_accuracy(self) -> float:          # metric A
        return self.correctly_confirmed / self.confirm_cases if self.confirm_cases else 1.0

    @property
    def unsafe_blocking_accuracy(self) -> float:             # metric B
        return self.correctly_blocked / self.review_cases if self.review_cases else 1.0

    @property
    def case_false_confirmation_rate(self) -> float:         # metric C: unsafe cases incorrectly confirmed
        return self.false_confirmed_cases / self.review_cases if self.review_cases else 0.0

    @property
    def p0_count(self) -> int:
        """P0 = DEMONSTRATED unsafe behaviour: an unsafe request reached CONFIRMED in this run."""
        return self.false_confirmed_cases + self.wrong_confirmed_cases

    @property
    def precision(self) -> float:
        return self.correct_items / self.found_items if self.found_items else 0.0

    @property
    def recall(self) -> float:
        return self.correct_items / self.expected_items if self.expected_items else 0.0

    @property
    def flag_recall(self) -> float:
        return self.found_flags / self.expected_flags if self.expected_flags else 1.0

    @property
    def false_confirmation_rate(self) -> float:
        return self.false_confirmations / self.confirmed_items if self.confirmed_items else 0.0


def _key(pid, qty, size):
    return (pid, None if qty is None else round(float(qty), 3), size)


STATUSES = ("CONFIRMED", "NEEDS_REVIEW")


def load_cases(path: str):
    """Strict: every case must carry exactly one valid expected_status (so it can never be guessed per case)."""
    with open(path, encoding="utf-8") as f:
        cases = [json.loads(l) for l in f if l.strip()]
    for i, c in enumerate(cases, 1):
        if c.get("expected_status") not in STATUSES:
            raise ValueError(f"case {i}: expected_status must be exactly one of {STATUSES}, got {c.get('expected_status')!r}")
    return cases


def _expected_status(c) -> (str, bool):
    """(status, was_inferred). Only for cases built in code without the field: all-confirmable and flag-free."""
    st = c.get("expected_status")
    if st is not None:
        if st not in STATUSES:
            raise ValueError(f"expected_status must be one of {STATUSES}, got {st!r}")
        return st, False
    clean = not c.get("expected_flags") and c.get("expected") and all(e.get("confirm", True) for e in c["expected"])
    return ("CONFIRMED" if clean else "NEEDS_REVIEW"), True


def run_eval(cases, catalog: Catalog, extractor: Extractor) -> EvalResult:
    r = EvalResult()
    for i, c in enumerate(cases, 1):
        status, inferred = _expected_status(c)
        r.inferred_status_cases += inferred
        voice = set(c.get("voice", []))
        msgs = [Message("Customer", t, voice=j in voice) for j, t in enumerate(c["messages"])]
        r.cases += 1
        r.confirm_cases += status == "CONFIRMED"
        r.review_cases += status == "NEEDS_REVIEW"
        try:
            order = build_order("Customer", msgs, catalog, extractor)
        except Exception as e:                # extraction/transport failure: no order object exists, so nothing was confirmed
            r.execution_failures += 1
            r.failures.append(f"case {i}: EXECUTION FAILURE (failed closed, nothing confirmed): {type(e).__name__}: {e}")
            continue
        got = [_key(l.product_id, l.quantity, l.size) for l in order.lines if l.product_id]
        confirmed = [_key(l.product_id, l.quantity, l.size) for l in order.lines if l.product_id and l.status == "ok"]
        want_flags = set(c.get("expected_flags", []))
        exp_items = c.get("expected", [])
        exp = [_key(e["product"], e.get("quantity"), e.get("size")) for e in exp_items]
        exp_ok = [_key(e["product"], e.get("quantity"), e.get("size")) for e in exp_items
                  if e.get("confirm", not want_flags)]
        got_all = [_key(l.product_id, l.quantity, l.size) for l in order.lines]   # every line, even unmatched ones
        remaining = list(got)
        ok = 0
        for e in exp:
            if e in remaining:
                remaining.remove(e)
                ok += 1
        allowed = list(exp_ok)
        false_conf = 0
        for k in confirmed:                   # a confirmed line must be one the case says may be confirmed
            if k in allowed:
                allowed.remove(k)
            else:
                false_conf += 1
        omitted = order.status == "CONFIRMED" and len(got) < len(exp)    # confirmed although items disappeared
        if omitted:
            false_conf += 1
        r.expected_items += len(exp)
        r.found_items += len(got)
        r.correct_items += ok
        r.confirmed_items += len(confirmed)
        r.false_confirmations += false_conf
        r.missed_confirms += len(allowed)
        # ---- case-level status verdict ----
        if order.status == "CONFIRMED":
            same = Counter(got_all) == Counter(exp)
            if status == "NEEDS_REVIEW":
                r.false_confirmed_cases += 1
                r.p0.append(f"case {i}: FALSE CONFIRMATION - expected NEEDS_REVIEW, got CONFIRMED {got_all}")
            elif not same:
                r.wrong_confirmed_cases += 1
                r.p0.append(f"case {i}: WRONG CONFIRMED ORDER - expected {exp}, confirmed {got_all}")
            else:
                r.correctly_confirmed += 1
        elif status == "CONFIRMED":
            r.false_rejections += 1
            why = sorted({f.code for l in order.lines for f in l.flags}) or order.warnings
            r.rejections.append(f"case {i}: expected CONFIRMED, got NEEDS_REVIEW ({why})")
        else:
            r.correctly_blocked += 1
        have_flags = {f.code for l in order.lines for f in l.flags}
        r.expected_flags += len(want_flags)
        r.found_flags += len(want_flags & have_flags)
        r.extra_flags += len(have_flags - want_flags)
        if ok != len(exp) or len(got) != len(exp) or want_flags - have_flags or false_conf:
            tag = f" FALSE CONFIRMATION x{false_conf}" if false_conf else ""
            tag += " (ORDER CONFIRMED WITH MISSING ITEMS)" if omitted else ""
            r.failures.append(f"case {i}:{tag} expected {exp} flags {sorted(want_flags)} | got {got} flags {sorted(have_flags)}")
    return r


def render(r: EvalResult) -> str:
    out = [f"cases: {r.cases}",
           f"items  precision {r.precision:.0%}  recall {r.recall:.0%}  ({r.correct_items} correct / {r.expected_items} expected / {r.found_items} found)",
           f"flags  expected {r.expected_flags}, caught {r.found_flags} ({r.flag_recall:.0%}), unexpected {r.extra_flags}",
           f"confirm  confirmed {r.confirmed_items}, FALSE confirmations {r.false_confirmations} "
           f"({r.false_confirmation_rate:.0%}), confirmable-but-asked {r.missed_confirms}"]
    out += ["",
            f"status  valid-order confirmation accuracy (A): {r.correctly_confirmed}/{r.confirm_cases} = {r.valid_confirmation_accuracy:.0%}"
            f"   false rejections: {r.false_rejections}",
            f"        unsafe-order blocking accuracy     (B): {r.correctly_blocked}/{r.review_cases} = {r.unsafe_blocking_accuracy:.0%}",
            f"        FALSE CONFIRMATION RATE            (C): {r.false_confirmed_cases}/{r.review_cases} = {r.case_false_confirmation_rate:.0%}"
            f"   (target 0)   wrong confirmed orders: {r.wrong_confirmed_cases}   execution failures: {r.execution_failures}"]
    if r.inferred_status_cases:
        out.append(f"        WARNING: {r.inferred_status_cases} case(s) had no expected_status (inferred; add it)")
    out += ["", "P0 FINDINGS:"] + (["  " + x for x in r.p0] or ["  none"])
    out += ["", "False rejections (usability, not safety):"] + (["  " + x for x in r.rejections] or ["  none"])
    out += ["", "Mismatches:"] + (r.failures or ["  none"])
    return "\n".join(out)


# ---------------------------------------------------------------------------------------------------------
# AUDIT STATUS vs READINESS. Two independent fields; never merged.
#   P0 = a demonstrated unsafe CONFIRMED.   P1 = a known limitation NOT demonstrated unsafe in this run.
#   A P1 never stops the audit; it only caps the readiness verdict. A P1 is promoted to P0 only by demonstration.
# ---------------------------------------------------------------------------------------------------------
KNOWN_P1 = [
    "Unknown catalog product omitted by the extractor can escape the completeness check when the wording gives "
    "coverage.py no evidence (no unit, no separator, no known name): e.g. '2 kg rice, 3 bellam'.",
]


def _digest(d) -> str:
    return (d or "").lower().replace("sha256:", "")


def probe_model(model: str, host: str, expect_digest=None, opener=None) -> dict:
    """Is the REAL model reachable, and can we say which model it is?  Returns
    {available, provenance: VERIFIED|PARTIALLY VERIFIED|NOT VERIFIED, detail}.
      VERIFIED            Gemma-family model present locally AND its digest matches --expect-digest.
      PARTIALLY VERIFIED  Gemma family and a digest are reported, but no expected digest was supplied to compare.
      NOT VERIFIED        anything else (wrong family, no digest, digest mismatch)."""
    import urllib.request
    opener = opener or urllib.request.urlopen
    try:
        with opener(host.rstrip("/") + "/api/tags", timeout=5) as resp:
            tags = json.load(resp).get("models", [])
    except Exception as e:
        return {"available": False, "provenance": "NOT VERIFIED", "detail": f"Ollama not reachable at {host}: {e}"}
    names = {model, model if ":" in model else model + ":latest"}
    entry = next((m for m in tags if m.get("name") in names or m.get("model") in names), None)
    if entry is None:
        return {"available": False, "provenance": "NOT VERIFIED", "detail": f"model {model!r} is not pulled in Ollama"}
    family = str((entry.get("details") or {}).get("family", "")).lower()
    digest = _digest(entry.get("digest"))
    if not family.startswith("gemma") or not digest:
        return {"available": True, "provenance": "NOT VERIFIED",
                "detail": f"family={family or '?'} digest={'present' if digest else 'missing'}"}
    if expect_digest:
        ok = digest.startswith(_digest(expect_digest)) or _digest(expect_digest).startswith(digest)
        return {"available": True, "provenance": "VERIFIED" if ok else "NOT VERIFIED",
                "detail": f"digest {digest[:12]} " + ("matches" if ok else f"does NOT match expected {_digest(expect_digest)[:12]}")}
    return {"available": True, "provenance": "PARTIALLY VERIFIED",
            "detail": f"gemma-family model, digest {digest[:12]}; no --expect-digest given, so the weights are not proven"}


def whisper_status() -> str:
    """The eval is text-only. Whisper is never exercised here, so the honest answer is NO (or NOT AVAILABLE)."""
    try:
        import faster_whisper  # noqa: F401
    except ImportError:
        return "NOT AVAILABLE"
    return "NO"


def audit_result(res: EvalResult, probe: dict, whisper: str, code_modified: bool = False) -> dict:
    p0, p1 = res.p0_count, len(KNOWN_P1)
    if not probe["available"]:
        status, ready = "STOPPED - REAL MODEL UNAVAILABLE", "NOT ASSESSED"
    elif probe["provenance"] == "NOT VERIFIED":
        status, ready = "STOPPED - PROVENANCE UNVERIFIED", "NOT ASSESSED"
    elif p0:
        status, ready = "STOPPED - P0 FALSE CONFIRMATION FOUND", "NOT READY"
    elif res.execution_failures:      # added rule: untested cases mean the evidence is not trustworthy
        status, ready = f"STOPPED - {res.execution_failures} CASE(S) COULD NOT BE EXECUTED", "NOT ASSESSED"
    else:
        status = "COMPLETED"
        ready = ("DEMO / CONTROLLED HUMAN REVIEW ONLY - KNOWN P1 LIMITATION" if p1
                 else "DEMO / CONTROLLED HUMAN REVIEW READY")
    return {"gemma": "YES" if probe["available"] else "NO", "provenance": probe["provenance"], "whisper": whisper,
            "p0": p0, "p1": p1, "ran": res.cases > 0, "status": status, "readiness": ready,
            "code_modified": "YES" if code_modified else "NO", "detail": probe["detail"]}


def render_audit_result(a: dict) -> str:
    return "\n".join([
        "AUDIT RESULT", "------------", "",
        f"Real Gemma available: {a['gemma']}",
        f"Model provenance: {a['provenance']}",
        f"Real Whisper tested: {a['whisper']}", "",
        f"P0 false confirmations: {a['p0'] if a['ran'] else 'NOT TESTED (no real-model cases were run)'}",
        f"P1 limitations: {a['p1']}", "",
        "AUDIT STATUS:", a["status"], "",
        "READINESS VERDICT:", a["readiness"], "",
        f"Code modified during evaluation: {a['code_modified']}",
    ])
