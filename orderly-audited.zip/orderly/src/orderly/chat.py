"""Parse WhatsApp chat exports (Android and iOS styles) or plain pasted lines into messages."""
import re
from collections import OrderedDict
from dataclasses import dataclass, replace
from typing import Dict, List, Optional

UNCLEAR = "[unclear audio]"
MISSING = "[voice note file missing]"
VOICE_TAG = "[voice note]"        # marks text that came from speech recognition (also added by the web UI)


@dataclass
class Message:
    sender: str
    text: str = ""
    kind: str = "text"                # text | audio (not yet transcribed) | media (photo/other: NOT read)
    attachment: Optional[str] = None  # file name for audio / media messages
    ts: Optional[str] = None
    voice: bool = False               # text is a speech-to-text transcript


_DATE = (r"(?:\d{1,2}[/.\-]\d{1,2}[/.\-]\d{2,4}|\d{4}[/.\-]\d{1,2}[/.\-]\d{1,2}"
         r"|\d{1,2}\s+[A-Za-z]{3,9}\.?\s+\d{2,4}|[A-Za-z]{3,9}\.?\s+\d{1,2},?\s+\d{4})")
_TIME = r"\d{1,2}:\d{2}(?::\d{2})?(?:\s?[APap]\.?[Mm]\.?)?"
_LINE = re.compile(rf"^\[?({_DATE}),?\s+({_TIME})\]?\s*(?:-\s*)?([^:]{{1,60}}?):\s(.*)$")
_STAMP = re.compile(rf"^\[?{_DATE},?\s+\d{{1,2}}:\d{{2}}")
_LOOSE = re.compile(r"\d{1,2}[:.]\d{2}(?:[:.]\d{2})?[^:\n]{0,12}?[-\]]\s*[^:\n]{1,60}:\s")
_SYSTEM_SENDER = re.compile(r'["\u201c]|\s(?:created|added|removed|changed|joined|left|deleted|pinned|updated)\s')
_ATTACH_A = re.compile(r"<attached:\s*([^>]+)>")
_ATTACH_B = re.compile(r"^(\S.*?\.\w{2,5})\s*\(file attached\)")
_OMITTED = re.compile(r"^<?(?:media|image|video|audio|sticker|gif|document|contact card)\s+omitted>?$", re.I)
_EDITED = re.compile(r"\s*<This message was edited>$", re.I)
_AUDIO_EXT = (".opus", ".ogg", ".m4a", ".mp3", ".wav", ".aac", ".amr", ".webm", ".flac")


def _clean(s: str) -> str:
    return (s.replace("\ufeff", "").replace("\u200e", "").replace("\u200f", "").replace("\u202f", " ").strip())


def _to_messages(sender: str, ts: str, body: str) -> List[Message]:
    body = _EDITED.sub("", _clean(body))
    if not body or body.lower() in ("this message was deleted", "you deleted this message"):
        return []
    if _OMITTED.match(body):
        return [Message(sender, kind="media", ts=ts)]     # content unknown (could be a voice note): never silent
    m = _ATTACH_A.search(body) or _ATTACH_B.match(body)
    if m:
        name = m.group(1).strip()
        rest = (body[:m.start()] + " " + body[m.end():]).strip()
        kind = "audio" if name.lower().endswith(_AUDIO_EXT) else "media"
        out = [Message(sender, kind=kind, attachment=name, ts=ts)]
        if rest:                                          # a caption is the customer's own words: keep it
            out.append(Message(sender, rest, ts=ts))
        return out
    return [Message(sender, body, ts=ts)]


def parse_chat(text: str) -> List[Message]:
    raw: List[List[str]] = []
    open_msg = False                          # can the next unstamped line continue the last message?
    for line in text.splitlines():
        clean = _clean(line)
        m = _LINE.match(clean) if clean else None
        if m and _SYSTEM_SENDER.search(m.group(3)):
            m = None                          # "X created group "A: B"": a system line, not a customer
        if m:
            raw.append([m.group(3).strip(), m.group(1) + " " + m.group(2), m.group(4)])
            open_msg = True
        elif _STAMP.match(clean):
            open_msg = False                  # system line ("Messages are encrypted"): not part of any message
        elif raw and open_msg and clean:
            raw[-1][2] += "\n" + line        # continuation of a multi-line message
    msgs: List[Message] = []
    for s, t, b in raw:
        msgs += _to_messages(s, t, b)
    return msgs


def parse_input(text: str, default_sender: str = "Customer") -> List[Message]:
    """WhatsApp export if it looks like one, otherwise one message per non-empty line."""
    msgs = parse_chat(text)
    if msgs:
        return msgs
    cleaned = [_clean(ln) for ln in text.splitlines()]
    if any(_STAMP.match(c) for c in cleaned):
        return []                             # a recognised export with no customer messages
    if sum(1 for c in cleaned if _LOOSE.search(c[:90])) >= 2:
        raise ValueError("this looks like a WhatsApp export in a date format Orderly does not understand; "
                         "not guessing (it would mix every participant into one order)")
    return [Message(default_sender, ln.strip()) for ln in text.splitlines() if ln.strip()]


def group_by_sender(messages: List[Message], owner: Optional[str] = None) -> Dict[str, List[Message]]:
    groups: "OrderedDict[str, List[Message]]" = OrderedDict()
    for m in messages:
        if owner and m.sender.strip().lower() == owner.strip().lower():
            continue
        groups.setdefault(m.sender, []).append(m)
    return groups


def with_text(m: Message, text: str) -> Message:
    return replace(m, text=text, kind="text", voice=m.voice or m.kind == "audio")
