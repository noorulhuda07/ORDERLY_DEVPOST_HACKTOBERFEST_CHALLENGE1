"""Unit and size normalisation (English, Telugu script, common transliterations)."""
import re
import string
from typing import Optional, Set

UNIT_ALIASES = {
    "kg": "kg", "kgs": "kg", "kilo": "kg", "kilos": "kg", "kilogram": "kg", "kilograms": "kg",
    "కిలో": "kg", "కిలోలు": "kg", "కేజీ": "kg", "కేజీలు": "kg",
    "g": "g", "gm": "g", "gms": "g", "gram": "g", "grams": "g", "గ్రాములు": "g", "గ్రాం": "g",
    "l": "l", "lt": "l", "ltr": "l", "litre": "l", "liter": "l", "litres": "l", "liters": "l",
    "లీటర్": "l", "లీటర్లు": "l",
    "ml": "ml",
    "pcs": "pcs", "pc": "pcs", "piece": "pcs", "pieces": "pcs", "nos": "pcs", "no": "pcs",
    "packet": "packet", "packets": "packet", "pkt": "packet", "pkts": "packet", "pack": "packet",
    "ప్యాకెట్": "packet", "ప్యాకెట్లు": "packet",
    "dozen": "dozen", "dozens": "dozen", "doz": "dozen", "dz": "dozen",
    "డజను": "dozen", "డజన్": "dozen", "డజన్లు": "dozen", "డజనులు": "dozen",
}

# Number words that carry a quantity (used only to CHECK the model's number against the customer's text).
NUMBER_WORDS = {
    "oka": 1, "okati": 1, "ఒక": 1, "ఒకటి": 1, "one": 1,
    "rendu": 2, "రెండు": 2, "two": 2, "moodu": 3, "మూడు": 3, "three": 3,
    "nalugu": 4, "నాలుగు": 4, "four": 4, "aidu": 5, "ఐదు": 5, "అయిదు": 5, "five": 5,
    "aaru": 6, "ఆరు": 6, "six": 6, "edu": 7, "ఏడు": 7, "seven": 7,
    "enimidi": 8, "ఎనిమిది": 8, "eight": 8, "tommidi": 9, "తొమ్మిది": 9, "nine": 9,
    "padi": 10, "పది": 10, "ten": 10,
    "ara": 0.5, "అర": 0.5, "half": 0.5, "pavu": 0.25, "పావు": 0.25, "quarter": 0.25,
    "okatinnara": 1.5, "ఒకటిన్నర": 1.5, "rendunnara": 2.5, "రెండున్నర": 2.5,
}

_COUNT = {"pcs", "packet"}
_CONVERT = {("g", "kg"): 0.001, ("kg", "g"): 1000.0, ("ml", "l"): 0.001, ("l", "ml"): 1000.0,
            ("dozen", "pcs"): 12.0, ("dozen", "packet"): 12.0}
_PUNCT = {ord(c): " " for c in string.punctuation}
_INVISIBLE = {0x200C: None, 0x200D: None, 0x200E: None, 0x200F: None}


def normalize_unit(u: Optional[str]) -> Optional[str]:
    if not u:
        return None
    return UNIT_ALIASES.get(u.strip().lower().rstrip("."))


def compatible(unit: str, base: str) -> bool:
    return unit == base or (unit in _COUNT and base in _COUNT) or (unit, base) in _CONVERT


def convert(qty: float, unit: str, base: str) -> float:
    if unit == base or (unit in _COUNT and base in _COUNT):
        return qty
    return round(qty * _CONVERT[(unit, base)], 9)      # rounded: 700 g must be 0.7 kg, not 0.7000000000000001


def _fmt(x: float) -> str:
    return str(int(x)) if float(x).is_integer() else str(x)


def normalize_size(s: Optional[str]) -> Optional[str]:
    """'1 Litre' -> '1l', '500 gm' -> '500g'. Returns None if it doesn't look like a size."""
    if not s:
        return None
    m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*([A-Za-z]+)\s*", s)
    if not m:
        return None
    unit = normalize_unit(m.group(2))
    if not unit:
        return None
    return f"{_fmt(float(m.group(1)))}{unit}"


# ---- evidence extraction: what does the CUSTOMER'S text actually contain? --------------------------------

def _tokens(text: str):
    return text.translate(_INVISIBLE).lower().translate(_PUNCT).split()


_NUM = re.compile(r"(\d+)\s*/\s*(\d+)|(\d+)\s*([½¼¾])|(\d+(?:[.,]\d+)?)")
_FRAC = {"½": 0.5, "¼": 0.25, "¾": 0.75}


_CLOCK = re.compile(r"\d{1,2}:\d{2}(?::\d{2})?")
SEGMENT_SPLIT = re.compile(r"[\n,;&+]|[.!?](?!\d)|\b(?:and|also|plus)\b|మరియు")


def segments_of(text: str):
    """Split customer text into item-sized pieces (the same cut coverage.py uses to count items)."""
    return SEGMENT_SPLIT.split((text or "").lower())


def quantities_in(text: str) -> Set[float]:
    """Every number (digits, fractions) and number word that appears in the text (clock times excluded)."""
    t = _CLOCK.sub(" ", (text or "").translate(_INVISIBLE).lower())
    out: Set[float] = set()
    for m in _NUM.finditer(t):
        if m.group(1):
            d = int(m.group(2))
            if d:
                out.add(int(m.group(1)) / d)
        elif m.group(3):
            out.add(int(m.group(3)) + _FRAC[m.group(4)])
        else:
            s = m.group(5)
            for v in (s.replace(",", ""), s.replace(",", ".")):
                try:
                    out.add(float(v))
                except ValueError:
                    pass
    for ch, v in _FRAC.items():
        if ch in t:
            out.add(v)
    for tok in _tokens(t):
        if tok in NUMBER_WORDS:
            out.add(float(NUMBER_WORDS[tok]))
    return out


def units_in(text: str) -> Set[str]:
    out = set()
    for tok in _tokens(text or ""):
        u = normalize_unit(re.sub(r"^\d+", "", tok))
        if u:
            out.add(u)
    return out


_SIZE = re.compile(r"(\d+(?:\.\d+)?)\s*([^\s\d,;:!?()\[\]]+)")


def sizes_in(text: str) -> Set[str]:
    out = set()
    for m in _SIZE.finditer((text or "").lower()):
        s = normalize_size(m.group(1) + m.group(2).strip(".-"))
        if s:
            out.add(s)
    return out
