from dataclasses import dataclass, field
from typing import List, Optional

from .catalog import Catalog, norm
from .chat import MISSING, UNCLEAR, VOICE_TAG, Message, group_by_sender
from .coverage import omission_warning
from .extract import Extractor, RawOrder
from .validate import Flag, OrderLine, validate_item

# Words that mean the customer changed their mind. The model is trusted to apply a correction, never to be
# right about it silently: any such cue makes every line ask for a final confirmation.
CORRECTION_CUES = {"actually", "instead", "correction", "sorry", "change", "changed", "cancel", "remove",
                   "wait", "not", "no", "kaadu", "కాదు", "వద్దు", "తీసేయండి", "మార్చండి",
                   # cancellations / second thoughts the first list missed (found by the final audit)
                   "vaddu", "vaddhu", "vadu", "ledu", "లేదు", "avasaram", "dont", "don", "didn", "doesn", "wont",
                   "make", "only", "rather", "typo", "mistake", "oops", "ignore", "leave", "skip", "forget", "drop",
                   "replace", "update", "except", "without"}


@dataclass
class Order:
    customer: str
    lines: List[OrderLine] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    notes: Optional[str] = None
    messages: List[str] = field(default_factory=list)

    @property
    def confirmed_total(self) -> float:
        return round(sum(l.total or 0 for l in self.lines if l.status == "ok"), 2)

    @property
    def needs_reply(self) -> int:
        return sum(1 for l in self.lines if l.status == "needs_reply")

    @property
    def status(self) -> str:
        """CONFIRMED only if there is at least one line, every line passed validation and nothing warns."""
        ok = bool(self.lines) and all(l.status == "ok" for l in self.lines) and not self.warnings
        return "CONFIRMED" if ok else "NEEDS_REVIEW"


def _q(l: OrderLine) -> str:
    if l.quantity is None:
        return "?"
    q = int(l.quantity) if float(l.quantity).is_integer() else l.quantity
    return f"{q} {l.unit or ''}".strip()


def _flag_voice(order: Order, msgs: List[Message]) -> None:
    """Speech-to-text is untrusted: a line heard in a voice note always has to be confirmed."""
    voice = [f" {norm(m.text)} " for m in msgs if m.voice or VOICE_TAG in m.text]
    typed = [f" {norm(m.text)} " for m in msgs if not (m.voice or VOICE_TAG in m.text)]
    for l in order.lines:
        w = norm(l.raw)
        # fail closed: also flag when the wording is not inside any single typed message (it may be stitched
        # together across a voice note and a text, so the "heard in a voice note" check could not see it)
        if voice and l.product_id and w and (any(f" {w} " in t for t in voice)
                                             or not any(f" {w} " in t for t in typed)):
            l.flags.append(Flag("voice_confirm", f"{l.product_name}: heard in a voice note ({_q(l)})",
                                f"{l.product_name}: we heard {_q(l)} in your voice note. Is that right?",
                                f"{l.product_name}: మీ వాయిస్ నోట్‌లో {_q(l)} విన్నాం. సరైనదేనా?"))


def _flag_duplicates(order: Order) -> None:
    groups = {}
    for l in order.lines:
        if l.product_id:
            groups.setdefault((l.product_id, l.size), []).append(l)
    for g in groups.values():
        if len(g) > 1:
            seen = " and ".join(_q(l) for l in g)
            for l in g:
                l.flags.append(Flag("duplicate_product", f"{l.product_name} appears {len(g)} times ({seen})",
                                    f"{l.product_name}: we have {seen}. What is the final amount?",
                                    f"{l.product_name}: {seen} ఉన్నాయి. చివరికి ఎంత కావాలి?"))


def _flag_corrections(order: Order, msgs: List[Message]) -> None:
    if not any(t in CORRECTION_CUES for m in msgs for t in norm(m.text).split()):
        return
    for l in order.lines:
        if l.product_id:
            l.flags.append(Flag("correction_check", f"{l.product_name}: the customer changed something ({_q(l)})",
                                f"{l.product_name}: you changed your order. Final amount {_q(l)} - is that right?",
                                f"{l.product_name}: ఆర్డర్ మార్చారు. చివరికి {_q(l)} - సరైనదేనా?"))


def build_order(sender: str, messages: List[Message], catalog: Catalog, extractor: Extractor) -> Order:
    readable = [m for m in messages if m.kind == "text"]       # audio / media that were not read never reach the model
    raw: RawOrder = extractor.extract(sender, readable, catalog)
    source = "\n".join(m.text for m in readable)
    # The customer is whoever sent the messages: the model's guess at a name is never used.
    order = Order(customer=sender, notes=raw.notes, messages=[m.text for m in readable])
    order.lines = [validate_item(it, catalog, source) for it in raw.items]
    _flag_voice(order, readable)
    _flag_duplicates(order)
    _flag_corrections(order, readable)
    missing = omission_warning([m.text for m in readable], order.lines, catalog)   # items the model may have dropped
    if missing:
        order.warnings.append(missing)
    skipped = [m for m in messages if m.kind != "text"]
    if skipped:
        order.warnings.append(f"{len(skipped)} voice note(s)/attachment(s) could not be read (not exported, file missing, "
                              "or no speech model). Their items are NOT in this list.")
    if any(UNCLEAR in m.text for m in readable):
        order.warnings.append("A voice note was hard to hear. Please double-check this order with the customer.")
    if any(MISSING in m.text for m in readable):
        order.warnings.append("A voice note could not be read (file missing or no speech model). Its items are NOT in this list.")
    if not order.lines:
        order.warnings.append("No items found in these messages.")
    return order


def process(messages: List[Message], catalog: Catalog, extractor: Extractor, owner: Optional[str] = None) -> List[Order]:
    return [build_order(s, ms, catalog, extractor) for s, ms in group_by_sender(messages, owner).items()]
