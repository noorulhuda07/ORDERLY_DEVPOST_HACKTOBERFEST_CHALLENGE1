import json
from dataclasses import asdict
from typing import List

from .pipeline import Order


def reply_text(order: Order) -> str:
    """One message the shopkeeper can paste back to the customer, in English and Telugu."""
    flagged = [(f, l) for l in order.lines for f in l.flags]
    if not flagged:
        return ""
    out = [f"Hi {order.customer}! Quick check on your order / మీ ఆర్డర్ గురించి చిన్న సందేహాలు:"]
    for i, (f, _l) in enumerate(flagged, 1):
        out.append(f"{i}. {f.question_en}\n   {f.question_te}")
    return "\n".join(out)


def _m(x: float) -> str:
    return f"{x:.2f}".rstrip("0").rstrip(".")


def to_dict(order: Order, currency: str = "₹") -> dict:
    d = asdict(order)
    d["status"] = order.status
    for ln, src in zip(d["lines"], order.lines):
        ln["status"] = src.status
    d["confirmed_total"] = order.confirmed_total
    d["needs_reply"] = order.needs_reply
    d["reply"] = reply_text(order)
    d["currency"] = currency
    return d


def to_json(orders: List[Order], currency: str = "₹") -> str:
    return json.dumps([to_dict(o, currency) for o in orders], indent=2, ensure_ascii=False)


def _q(l) -> str:
    if l.quantity is None:
        return "?"
    q = int(l.quantity) if float(l.quantity).is_integer() else l.quantity
    return f"{q} {l.unit or ''}".strip()


def render_text(orders: List[Order], currency: str = "₹") -> str:
    out = []
    for o in orders:
        out += [f"ORDER: {o.customer}   [{o.status}]", "-" * 44]
        for l in o.lines:
            name = l.product_name or f"? {l.raw}"
            size = f" [{l.size}]" if l.size else ""
            mark = "ok " if l.status == "ok" else "ASK"
            price = f"{currency}{_m(l.total)}" if l.total is not None else ""
            out.append(f"  [{mark}] {name}{size}  x {_q(l)}  {price}".rstrip())
            for f in l.flags:
                out.append(f"          -> {f.message}")
        out.append(f"  Confirmed total: {currency}{_m(o.confirmed_total)}   ({o.needs_reply} line(s) need a reply)")
        if o.notes:
            out.append(f"  Note: {o.notes}")
        for w in o.warnings:
            out.append(f"  ! {w}")
        r = reply_text(o)
        if r:
            out += ["", "  Suggested reply:"] + ["  | " + ln for ln in r.splitlines()]
        out.append("")
    return "\n".join(out).rstrip()
