import os

from orderly.catalog import Catalog

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CATALOG_PATH = os.path.join(ROOT, "data", "catalog.sample.json")


def catalog():
    return Catalog.load(CATALOG_PATH)
