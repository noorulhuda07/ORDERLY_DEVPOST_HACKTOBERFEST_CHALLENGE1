"""A scripted stand-in for the LLM so the deterministic parts can be tested without a model."""
from orderly.extract import Extractor, RawItem, RawOrder


def item(raw, product=None, quantity=None, unit=None, size=None):
    return RawItem(raw, product or raw, quantity, unit, size)


class FakeExtractor(Extractor):
    def __init__(self, by_sender=None, default=None):
        self.by_sender, self.default, self.calls = by_sender or {}, default, []

    def extract(self, sender, messages, catalog):
        self.calls.append((sender, [m.text for m in messages]))
        return self.by_sender.get(sender, self.default or RawOrder())
