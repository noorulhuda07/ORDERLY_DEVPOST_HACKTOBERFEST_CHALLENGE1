import contextlib
import io
import json
import threading
import unittest
import urllib.request
from unittest import mock

from fakes import FakeExtractor, item
from helpers import CATALOG_PATH, ROOT, catalog
from orderly import cli, evaluate, report, webapp
from orderly.chat import UNCLEAR, parse_chat
from orderly.extract import RawOrder
from orderly.pipeline import process
from orderly.transcribe import Transcriber

import os

SCRIPT = {
    "Lakshmi Aunty": RawOrder(None, [item("biyyam", "Rice", 2, "kg"), item("oil", "oil"),
                                     item("gudlu", "Eggs", 1, "dozen")]),
    "Ravi": RawOrder(None, [item("sugar", "Sugar", 3, "kg"), item("tea powder", "Tea Powder", 2, "packet")]),
}


class PipelineTests(unittest.TestCase):
    def setUp(self):
        with open(os.path.join(ROOT, "data", "sample_chat.txt"), encoding="utf-8") as f:
            self.msgs = parse_chat(f.read())

    def test_one_order_per_customer_with_flags_and_totals(self):
        fx = FakeExtractor(SCRIPT)
        orders = process(self.msgs, catalog(), fx)
        by = {o.customer: o for o in orders}
        self.assertEqual(list(by), ["Lakshmi Aunty", "Ravi", "Suresh"])
        la = by["Lakshmi Aunty"]
        self.assertEqual(la.confirmed_total, 124.0 + 84.0)      # oil is flagged, so not counted
        self.assertEqual(la.needs_reply, 1)
        self.assertEqual(by["Ravi"].lines[1].flags[0].code, "missing_size")
        self.assertEqual(by["Suresh"].warnings, ["No items found in these messages."])
        # the model saw each customer's messages together, in order (so corrections are visible)
        self.assertEqual(fx.calls[1][1], ["5 kg sugar, 2 packet tea powder", "actually make sugar 3 kg"])

    def test_unclear_audio_warns(self):
        from orderly.chat import Message
        o = process([Message("A", f"2 kg rice {UNCLEAR}")], catalog(), FakeExtractor(default=RawOrder(None, [item("rice", "Rice", 2, "kg")])))[0]
        self.assertTrue(any("hard to hear" in w for w in o.warnings))

    def test_report_text_and_reply(self):
        orders = process(self.msgs, catalog(), FakeExtractor(SCRIPT))
        text = report.render_text(orders)
        self.assertIn("ORDER: Ravi", text)
        self.assertIn("[ASK] Tea Powder", text)
        self.assertIn("Suggested reply", text)
        reply = report.reply_text(orders[1])
        self.assertIn("ఏ సైజ్", reply)
        self.assertIn("which size?", reply)
        self.assertEqual(report.reply_text(process(self.msgs[:1], catalog(), FakeExtractor(default=RawOrder(None, [item("biyyam", "Rice", 2, "kg")])))[0]), "")
        data = json.loads(report.to_json(orders))
        self.assertEqual(data[0]["lines"][0]["status"], "ok")


class WebTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        class T(Transcriber):
            def transcribe(self, path):
                return "rendu kilolu biyyam", False

        cls.srv = webapp.make_server(catalog(), FakeExtractor(default=RawOrder(None, [item("biyyam", "Rice", 2, "kg"), item("karam", "Chilli Powder", 1, "packet")])), T(), port=0)
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()

    def post(self, path, data, headers=None):
        req = urllib.request.Request(self.base + path, data=data, headers=headers or {})
        with urllib.request.urlopen(req) as r:
            return json.load(r)

    def test_page_served(self):
        html = urllib.request.urlopen(self.base + "/").read().decode()
        self.assertIn("Orderly", html)
        self.assertNotIn("innerHTML", html)         # DOM built with textContent: no XSS from chat text

    def test_process(self):
        d = self.post("/api/process", json.dumps({"text": "2 kg biyyam, karam 1 packet"}).encode(),
                      {"Content-Type": "application/json"})
        o = d["orders"][0]
        self.assertEqual(o["customer"], "Customer")
        self.assertEqual(o["confirmed_total"], 124.0)
        self.assertEqual(o["needs_reply"], 1)
        self.assertIn("which size?", o["reply"])

    def test_transcribe(self):
        d = self.post("/api/transcribe", b"fakeaudio", {"X-Filename": "note.opus"})
        self.assertEqual(d["text"], "rendu kilolu biyyam")

    def test_bad_json_is_400(self):
        with self.assertRaises(urllib.error.HTTPError) as cm:
            self.post("/api/process", b"not json", {"Content-Type": "application/json"})
        self.assertEqual(cm.exception.code, 400)


class EvalAndCliTests(unittest.TestCase):
    def test_eval_perfect_and_imperfect(self):
        cases = [{"messages": ["x"], "expected": [{"product": "rice", "quantity": 2}], "expected_flags": []},
                 {"messages": ["y"], "expected": [{"product": "sugar", "quantity": 3}], "expected_flags": ["missing_size"]}]
        ex = FakeExtractor(default=RawOrder(None, [item("rice", "Rice", 2, "kg")]))
        r = evaluate.run_eval(cases, catalog(), ex)
        self.assertEqual((r.correct_items, r.expected_items, r.found_items), (1, 2, 2))
        self.assertEqual(r.flag_recall, 0.0)
        self.assertEqual(len(r.failures), 1)
        self.assertIn("recall", evaluate.render(r))

    def test_shipped_cases_load(self):
        cases = evaluate.load_cases(os.path.join(ROOT, "data", "eval_cases.jsonl"))
        self.assertGreaterEqual(len(cases), 5)

    def test_cli_run_text(self):
        ex = FakeExtractor(default=RawOrder(None, [item("biyyam", "Rice", 2, "kg")]))
        out = io.StringIO()
        with mock.patch.object(cli, "OllamaExtractor", return_value=ex), contextlib.redirect_stdout(out):
            code = cli.main(["--catalog", CATALOG_PATH, "run", "--text", "2 kg biyyam"])
        self.assertEqual(code, 0)
        self.assertIn("Rice", out.getvalue())

    def test_cli_missing_catalog(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err):
            code = cli.main(["--catalog", "/nope.json", "run", "--text", "x"])
        self.assertEqual(code, 2)


if __name__ == "__main__":
    unittest.main()
