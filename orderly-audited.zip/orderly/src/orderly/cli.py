import argparse
import sys

from . import evaluate, report
from .catalog import Catalog
from .chat import parse_input
from .extract import ExtractError, OllamaExtractor
from .pipeline import process
from .transcribe import FasterWhisperTranscriber, TranscribeError, resolve_audio


def _extractor(a):
    return OllamaExtractor(model=a.model, host=a.ollama_host)


def _transcriber(a, catalog):
    return FasterWhisperTranscriber(a.whisper_model, a.language, catalog.whisper_hint())


def cmd_run(a):
    catalog = Catalog.load(a.catalog)
    if a.text:
        msgs = parse_input(a.text)
    elif a.chat:
        with open(a.chat, encoding="utf-8-sig") as f:
            msgs = parse_input(f.read())
    else:
        print("error: give --chat FILE or --text MESSAGE", file=sys.stderr)
        return 2
    if any(m.kind == "audio" for m in msgs):
        tr = _transcriber(a, catalog) if a.audio_dir else None
        msgs = resolve_audio(msgs, a.audio_dir, tr)
    orders = process(msgs, catalog, _extractor(a), a.owner)
    print(report.to_json(orders, catalog.currency) if a.json else report.render_text(orders, catalog.currency))
    return 0 if all(o.status == "CONFIRMED" for o in orders) else 1     # 1 = something needs a human


def cmd_serve(a):
    from .webapp import make_server
    catalog = Catalog.load(a.catalog)
    tr = None if a.no_voice else _transcriber(a, catalog)
    srv = make_server(catalog, _extractor(a), tr, a.host, a.port)
    print(f"Orderly running at http://{a.host}:{a.port}  (Ctrl+C to stop)")
    if a.host not in ("127.0.0.1", "localhost", "::1"):
        print("  WARNING: not bound to this computer only. There is no login: anyone on the network can read orders.")
    print(f"  model: {a.model} via Ollama | voice: {'off' if tr is None else 'faster-whisper ' + a.whisper_model}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print()
    return 0


def cmd_eval(a):
    """Real-model audit. Read-only: it never edits code, the catalog or the cases."""
    catalog = Catalog.load(a.catalog)
    cases = evaluate.load_cases(a.cases)
    probe = evaluate.probe_model(a.model, a.ollama_host, a.expect_digest)
    if not probe["available"]:       # no real model: nothing can be claimed, so do not run (or fake) the cases
        print(f"{probe['detail']}\n")
        print(evaluate.render_audit_result(evaluate.audit_result(evaluate.EvalResult(), probe, evaluate.whisper_status())))
        return 2
    res = evaluate.run_eval(cases, catalog, _extractor(a))
    print(evaluate.render(res))
    print(f"\nmodel check: {probe['detail']}\nReal-model P0s are listed above; deterministic fake-extractor tests are in the unit tests.\n")
    out = evaluate.audit_result(res, probe, evaluate.whisper_status())
    print(evaluate.render_audit_result(out))
    return 1 if out["p0"] else (2 if out["status"].startswith("STOPPED") else 0)


def build_parser():
    p = argparse.ArgumentParser(prog="orderly", description="WhatsApp orders (Telugu + English) to a clean order list.")
    p.add_argument("--catalog", default="data/catalog.sample.json", help="shop catalog JSON")
    p.add_argument("--model", default="gemma3:4b", help="Ollama model used for extraction")
    p.add_argument("--ollama-host", default="http://localhost:11434")
    p.add_argument("--whisper-model", default="small", help="faster-whisper size: tiny/base/small/medium/large-v3")
    p.add_argument("--language", default=None, help="force speech language, e.g. te or en (default: auto)")
    sub = p.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="process a chat export or a message")
    r.add_argument("--chat", help="WhatsApp exported .txt (or any text file, one message per line)")
    r.add_argument("--text", help="message(s) typed directly")
    r.add_argument("--audio-dir", help="folder holding the voice-note files from the export")
    r.add_argument("--owner", help="the shop's own name in the chat (its messages are ignored)")
    r.add_argument("--json", action="store_true")
    r.set_defaults(fn=cmd_run)

    s = sub.add_parser("serve", help="start the local web UI")
    s.add_argument("--host", default="127.0.0.1")
    s.add_argument("--port", type=int, default=8000)
    s.add_argument("--no-voice", action="store_true", help="skip loading the speech model")
    s.set_defaults(fn=cmd_serve)

    e = sub.add_parser("eval", help="measure accuracy on labelled cases (jsonl)")
    e.add_argument("--cases", default="data/eval_cases.jsonl")
    e.add_argument("--expect-digest", help="expected model digest (sha256, prefix ok); needed for provenance VERIFIED")
    e.set_defaults(fn=cmd_eval)
    return p


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8")       # Telugu and the rupee sign on Windows / redirected output
        except Exception:
            pass
    a = build_parser().parse_args(argv)
    try:
        return a.fn(a)
    except (ExtractError, TranscribeError, FileNotFoundError, ValueError) as ex:
        print(f"error: {ex}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
