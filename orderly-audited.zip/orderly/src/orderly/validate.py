"""Deterministic checks. Everything the model said is verified here, against BOTH the catalog and the
customer's own words; anything doubtful becomes a flag with a ready-to-send question in English and Telugu.

A line is confirmable only if it ends up with no flags. The model's output is untrusted data:
  * the product is decided by the customer's words (`raw`), never by the model's choice of catalog name;
  * quantity, unit and size must literally appear in the customer's messages (when `source` is given);
  * an unrecognised unit is a flag, never "no unit".
"""
import math
import re
from dataclasses import dataclass, field
from typing import List, Optional

from .catalog import Catalog, Product, norm
from .extract import RawItem
from .units import (NUMBER_WORDS, compatible, convert, normalize_size, normalize_unit, quantities_in,
                    segments_of, sizes_in, units_in)

# NOTE for contributors: Telugu strings below are short templates; have a native speaker review them.

_NULLS = {"null", "none", "n/a", "na", "-", "nil"}


@dataclass
class Flag:
    code: str
    message: str
    question_en: str
    question_te: str


@dataclass
class OrderLine:
    raw: str
    product_id: Optional[str] = None
    product_name: Optional[str] = None
    quantity: Optional[float] = None
    unit: Optional[str] = None
    size: Optional[str] = None
    total: Optional[float] = None
    flags: List[Flag] = field(default_factory=list)

    @property
    def status(self) -> str:
        return "ok" if not self.flags else "needs_reply"


def _fmt(x: float) -> str:
    return str(int(x)) if float(x).is_integer() else f"{x:g}"


def _product_words(text: str) -> str:
    """The product part of the customer's words: drop numbers, units and number words ('2 kg biyyam' -> 'biyyam')."""
    toks = norm(text or "").split()
    keep = [t for t in toks if not (t.isdigit() or t in NUMBER_WORDS or normalize_unit(re.sub(r"^\d+", "", t)))]
    return " ".join(keep) or norm(text or "")


def _small(label: str):
    m = re.fullmatch(r"(\d+(?:\.\d+)?)([a-z]+)", label or "")
    if not m:
        return None
    v, u = float(m.group(1)), m.group(2)
    return {"kg": (v * 1000, "g"), "g": (v, "g"), "l": (v * 1000, "ml"), "ml": (v, "ml")}.get(u)


def _could_be_several_smaller_packs(p: Product, key: str) -> bool:
    """'5 l oil' is 1 x 5l but could also be 5 x 1l: the code must not pick one silently."""
    s = _small(normalize_size(key))
    for other in p.variants:
        o = _small(normalize_size(other))
        if other != key and s and o and o[1] == s[1] and o[0] < s[0]:
            ratio = s[0] / o[0]
            if abs(ratio - round(ratio)) < 1e-9:
                return True
    return False


def validate_item(item: RawItem, catalog: Catalog, source: Optional[str] = None) -> OrderLine:
    """`source` = the customer's messages for this order. Production code (pipeline.build_order) always passes it;
    without it only the catalog/unit/size rules run (used by unit tests of those rules)."""
    line = OrderLine(raw=item.raw)
    word = item.raw or item.product
    m = catalog.match(_product_words(word))          # the CUSTOMER's words decide what was asked for

    if m.status == "none":
        line.flags.append(Flag("unknown_product", f"'{word}' is not in the catalog",
                               f"We couldn't find '{word}'. Could you tell us the exact item?",
                               f"'{word}' మా లిస్ట్‌లో లేదు. ఏ వస్తువు కావాలో చెప్పండి."))
        return line
    if m.status == "ambiguous":
        names = [p.name for p in m.candidates]
        line.flags.append(Flag("ambiguous_product", f"'{word}' could be: {', '.join(names)}",
                               f"'{word}': which one - {' or '.join(names)}?",
                               f"'{word}': ఏది కావాలి - {' లేదా '.join(names)}?"))
        line.quantity = item.quantity
        return line

    p: Product = m.product
    line.product_id, line.product_name = p.id, p.name
    if m.status == "fuzzy":
        line.flags.append(Flag("confirm_product", f"'{word}' matched to {p.name} (not exact)",
                               f"Did you mean {p.name}?", f"{p.name} కావాలా?"))
    if item.product and item.product != item.raw:    # the model's own opinion must agree with the customer's words
        mp = catalog.match(_product_words(item.product))
        if mp.status in ("exact", "fuzzy") and mp.product.id != p.id:
            line.flags.append(Flag("product_mismatch", f"'{word}' looks like {p.name} but the reader said {mp.product.name}",
                                   f"'{word}': did you mean {p.name} or {mp.product.name}?",
                                   f"'{word}': {p.name} లేదా {mp.product.name}?"))

    qty = item.quantity
    raw_unit = (item.unit or "").strip()
    if raw_unit.lower() in _NULLS:
        raw_unit = ""
    unit = normalize_unit(raw_unit)
    size = item.size
    base = p.unit

    if source is not None:                           # evidence: is each fact really in the customer's text?
        # Quantity, unit and size must come from the SAME item-sized piece of text that names the product
        # ("2 kg rice, 5 kg sugar": rice cannot borrow sugar's 5). No such piece -> no evidence -> flagged.
        needle = f" {norm(word)} "
        evidence = "\n".join(s for s in segments_of(source) if needle in f" {norm(s)} ")
        if needle not in f" {norm(source)} ":
            line.flags.append(Flag("ungrounded_item", f"'{word}' does not appear in the customer's messages",
                                   f"Did you order '{word}'? We could not find it in your messages.",
                                   f"'{word}' ఆర్డర్ చేశారా? మీ మెసేజ్‌లలో కనిపించలేదు."))
        if qty is not None and math.isfinite(qty) and qty > 0 and \
                not any(abs(qty - n) < 1e-9 for n in quantities_in(evidence)):
            line.flags.append(Flag("unverified_quantity", f"{p.name}: quantity {_fmt(qty)} is not in the messages",
                                   f"{p.name}: how much do you need?", f"{p.name}: ఎంత కావాలి?"))
        if unit and unit != "pcs" and unit not in units_in(evidence):
            line.flags.append(Flag("unverified_unit", f"{p.name}: unit '{raw_unit}' is not in the messages",
                                   f"{p.name}: how many {base}?", f"{p.name}: ఎన్ని {base} కావాలి?"))
        if size and normalize_size(size) not in sizes_in(evidence):
            opts = " / ".join(p.variants) or base
            line.flags.append(Flag("unverified_size", f"{p.name}: size '{size}' is not in the messages",
                                   f"{p.name}: which size? ({opts})", f"{p.name}: ఏ సైజ్ కావాలి? ({opts})"))

    if raw_unit and unit is None:                    # never treat an unknown unit as "no unit"
        line.quantity = qty
        line.flags.append(Flag("bad_unit", f"{p.name}: unit '{raw_unit}' not understood",
                               f"{p.name}: we didn't understand '{raw_unit}'. How many {base}?",
                               f"{p.name}: '{raw_unit}' అర్థం కాలేదు. {base} లెక్కన ఎంత కావాలి?"))
        return line

    # Packaged products (with size variants): "1 litre oil" really means size 1l x 1
    if p.variants:
        line.unit = "pcs"
        if size is None and qty and unit in ("g", "ml", "kg", "l"):
            guess = normalize_size(f"{_fmt(qty)}{unit}")
            if guess and p.variant_key(guess):
                if qty != 1 and _could_be_several_smaller_packs(p, p.variant_key(guess)):
                    line.flags.append(Flag("ambiguous_size", f"{p.name}: '{_fmt(qty)} {unit}' could be one {guess} pack or several smaller packs",
                                           f"{p.name}: one {guess} pack, or several smaller packs? ({' / '.join(p.variants)})",
                                           f"{p.name}: ఒక {guess} ప్యాక్ లేదా చిన్న ప్యాకెట్లు? ({' / '.join(p.variants)})"))
                    return line
                size, qty, unit = guess, 1.0, None
            else:
                opts = " / ".join(p.variants)
                said = f"{_fmt(qty)}{unit}"
                line.flags.append(Flag("bad_size", f"{p.name}: '{said}' is not a size we sell",
                                       f"{p.name}: we have {opts}. Which one?",
                                       f"{p.name}: {opts} ఉన్నాయి. ఏది కావాలి?"))
                return line
        key = p.variant_key(size) if size else None
        if size is None:
            opts = " / ".join(p.variants)
            line.flags.append(Flag("missing_size", f"{p.name}: size not given",
                                   f"{p.name}: which size? ({opts})", f"{p.name}: ఏ సైజ్ కావాలి? ({opts})"))
        elif key is None:
            opts = " / ".join(p.variants)
            line.flags.append(Flag("bad_size", f"{p.name}: size '{size}' not sold",
                                   f"{p.name}: we have {opts}. Which one?", f"{p.name}: {opts} ఉన్నాయి. ఏది కావాలి?"))
        else:
            line.size = key
        if unit is not None and unit not in ("pcs", "packet", "dozen"):
            unit = None   # a stray weight unit next to a size: treat the number as a count

    if qty is None or not math.isfinite(qty) or qty <= 0:
        line.flags.append(Flag("missing_quantity", f"{p.name}: quantity not given",
                               f"{p.name}: how much do you need?", f"{p.name}: ఎంత కావాలి?"))
        return line

    if unit is None:
        if base in ("pcs", "packet"):
            unit = base
        else:
            line.quantity = qty
            line.flags.append(Flag("missing_unit", f"{p.name}: unit not given",
                                   f"{p.name}: how many {base}?", f"{p.name}: ఎన్ని {base} కావాలి?"))
            return line
    if not compatible(unit, base) or (unit == "packet" and base == "pcs" and not p.variants):
        # (a "packet" of eggs/soap is not one piece; for sized products "packet" just means "pack")
        line.flags.append(Flag("bad_unit", f"{p.name}: '{unit}' does not fit (sold per {base})",
                               f"{p.name}: we sell per {base}. How many {base}?",
                               f"{p.name}: {base} లెక్కన ఎంత కావాలి?"))
        return line

    qty = convert(qty, unit, base)
    line.quantity, line.unit = qty, base
    if base in ("pcs", "packet") and not float(qty).is_integer():
        line.flags.append(Flag("fractional_count", f"{p.name}: {_fmt(qty)} {base} (we sell whole {base} only)",
                               f"{p.name}: we sell whole {base} only. How many?",
                               f"{p.name}: పూర్తి {base} మాత్రమే. ఎన్ని కావాలి?"))
    if qty > p.max_qty:
        line.flags.append(Flag("large_quantity", f"{p.name}: {_fmt(qty)} {base} is unusually large",
                               f"{p.name}: {_fmt(qty)} {base} - is that right?",
                               f"{p.name}: {_fmt(qty)} {base} - సరైనదేనా?"))
    if not line.flags:
        price = p.variants[line.size] if p.variants else p.price
        line.total = round(price * qty, 2)
    return line
