import unittest

from orderly.chat import MISSING, UNCLEAR, Message, group_by_sender, parse_chat, parse_input, with_text
from orderly.transcribe import Transcriber, resolve_audio
import os
import tempfile

ANDROID = """04/10/2026, 09:12 - Ravi: 2 kg biyyam
and 1 kg pappu
04/10/2026, 09:13 - Ravi: PTT-20261004-WA0001.opus (file attached)
04/10/2026, 09:14 - Shop: ok anna
04/10/2026, 09:15 - Ravi: <Media omitted>
04/10/2026, 09:16 - Messages and calls are end-to-end encrypted.
"""
IOS = "[04/10/2026, 9:12:30 AM] Suresh: ‎<attached: 00000042-AUDIO-2026-10-04.opus>\n[04/10/2026, 9:13:00 AM] Suresh: 2 sabbu\n"


class FakeTranscriber(Transcriber):
    def __init__(self, text, low=False):
        self.text, self.low = text, low

    def transcribe(self, path):
        return self.text, self.low


class ChatTests(unittest.TestCase):
    def test_android_multiline_audio_and_noise(self):
        msgs = parse_chat(ANDROID)
        # "<Media omitted>" is no longer dropped silently: it becomes a "media" message that makes the order warn
        self.assertEqual([m.sender for m in msgs], ["Ravi", "Ravi", "Shop", "Ravi"])
        self.assertEqual(msgs[0].text, "2 kg biyyam\nand 1 kg pappu")
        self.assertEqual((msgs[1].kind, msgs[1].attachment), ("audio", "PTT-20261004-WA0001.opus"))
        self.assertEqual(msgs[3].kind, "media")

    def test_ios_format(self):
        msgs = parse_chat(IOS)
        self.assertEqual(msgs[0].kind, "audio")
        self.assertEqual(msgs[1].text, "2 sabbu")

    def test_plain_lines_become_one_customer(self):
        msgs = parse_input("2 kg rice\n\n1 oil\n")
        self.assertEqual([(m.sender, m.text) for m in msgs], [("Customer", "2 kg rice"), ("Customer", "1 oil")])

    def test_group_by_sender_skips_owner(self):
        g = group_by_sender(parse_chat(ANDROID), owner="shop")
        self.assertEqual(list(g), ["Ravi"])

    def test_resolve_audio(self):
        with tempfile.TemporaryDirectory() as d:
            open(os.path.join(d, "a.opus"), "wb").close()
            m = Message("Ravi", kind="audio", attachment="a.opus")
            ok = resolve_audio([m], d, FakeTranscriber("rendu kilolu biyyam"))[0]
            self.assertEqual((ok.kind, ok.text), ("text", "rendu kilolu biyyam"))
            low = resolve_audio([m], d, FakeTranscriber("rendu ...", low=True))[0]
            self.assertIn(UNCLEAR, low.text)
            gone = resolve_audio([Message("Ravi", kind="audio", attachment="nope.opus")], d, FakeTranscriber("x"))[0]
            self.assertIn(MISSING, gone.text)
            nomodel = resolve_audio([m], d, None)[0]
            self.assertIn(MISSING, nomodel.text)


if __name__ == "__main__":
    unittest.main()
