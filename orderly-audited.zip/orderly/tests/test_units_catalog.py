import unittest

from helpers import catalog
from orderly import units
from orderly.catalog import norm


class UnitTests(unittest.TestCase):
    def test_unit_aliases(self):
        self.assertEqual(units.normalize_unit("Kilos"), "kg")
        self.assertEqual(units.normalize_unit("కిలో"), "kg")
        self.assertEqual(units.normalize_unit("డజను"), "dozen")
        self.assertIsNone(units.normalize_unit("bucket"))
        self.assertIsNone(units.normalize_unit(None))

    def test_convert(self):
        self.assertEqual(units.convert(500, "g", "kg"), 0.5)
        self.assertEqual(units.convert(1, "dozen", "pcs"), 12)
        self.assertTrue(units.compatible("packet", "pcs"))
        self.assertFalse(units.compatible("kg", "l"))

    def test_sizes(self):
        self.assertEqual(units.normalize_size("1 Litre"), "1l")
        self.assertEqual(units.normalize_size("500 gm"), "500g")
        self.assertEqual(units.normalize_size("1.0 kg"), "1kg")
        self.assertIsNone(units.normalize_size("big"))


class CatalogTests(unittest.TestCase):
    def setUp(self):
        self.c = catalog()

    def test_norm_keeps_telugu_vowel_signs(self):
        self.assertEqual(norm("  బియ్యం! "), "బియ్యం")
        self.assertEqual(norm("Toor-Dal."), "toor dal")

    def test_exact_alias_matches_including_telugu(self):
        self.assertEqual(self.c.match("biyyam").product.id, "rice")
        self.assertEqual(self.c.match("బియ్యం").product.id, "rice")
        self.assertEqual(self.c.match("ఉల్లిపాయలు").product.id, "onion")

    def test_fuzzy_typo(self):
        m = self.c.match("biyam")
        self.assertEqual((m.status, m.product.id), ("fuzzy", "rice"))

    def test_generic_oil_is_ambiguous(self):
        m = self.c.match("oil")
        self.assertEqual(m.status, "ambiguous")
        self.assertEqual({p.id for p in m.candidates}, {"sunflower_oil", "groundnut_oil"})

    def test_specific_oil_is_exact(self):
        self.assertEqual(self.c.match("sunflower oil").product.id, "sunflower_oil")

    def test_unknown(self):
        self.assertEqual(self.c.match("laptop").status, "none")
        self.assertEqual(self.c.match("").status, "none")

    def test_prompt_and_whisper_hint(self):
        self.assertIn("Sunflower Oil", self.c.prompt_lines())
        self.assertIn("1l", self.c.prompt_lines())
        self.assertTrue(self.c.whisper_hint().startswith("Grocery order:"))


if __name__ == "__main__":
    unittest.main()
