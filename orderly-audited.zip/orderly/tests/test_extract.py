import io
import json
import unittest
from unittest import mock

from helpers import catalog
from orderly import extract
from orderly.chat import Message


class ParseTests(unittest.TestCase):
    def test_parse_plain_and_fenced(self):
        body = {"customer": "Ravi", "items": [
            {"raw": "biyyam", "product": "Rice", "quantity": "2", "unit": "kg", "size": None},
            {"raw": "oil", "product": "oil", "quantity": None, "unit": None, "size": None},
            "garbage"], "notes": "deliver by 6"}
        for text in (json.dumps(body), "```json\n" + json.dumps(body) + "\n```"):
            o = extract.parse_model_json(text)
            self.assertEqual((o.customer, o.notes, len(o.items)), ("Ravi", "deliver by 6", 2))
            self.assertEqual((o.items[0].quantity, o.items[0].unit), (2.0, "kg"))
            self.assertIsNone(o.items[1].quantity)

    def test_bad_json(self):
        with self.assertRaises(extract.ExtractError):
            extract.parse_model_json("sure! here is your order")
        with self.assertRaises(extract.ExtractError):
            extract.parse_model_json("[1,2]")

    def test_prompt_contains_catalog_and_messages(self):
        p = extract.build_user_prompt("Ravi", [Message("Ravi", "2 kg biyyam")], catalog())
        self.assertIn("Toor Dal", p)
        self.assertIn("1. 2 kg biyyam", p)


class OllamaTests(unittest.TestCase):
    def _fake_response(self, content):
        resp = io.BytesIO(json.dumps({"message": {"content": content}}).encode())
        resp.__enter__ = lambda s: s
        resp.__exit__ = lambda s, *a: False
        return resp

    def test_request_shape_and_parsing(self):
        content = json.dumps({"customer": None, "notes": None,
                              "items": [{"raw": "rice", "product": "Rice", "quantity": 1, "unit": "kg", "size": None}]})
        with mock.patch("urllib.request.urlopen", return_value=self._fake_response(content)) as up:
            o = extract.OllamaExtractor("gemma3:4b").extract("Ravi", [Message("Ravi", "1 kg rice")], catalog())
        req = up.call_args[0][0]
        sent = json.loads(req.data)
        self.assertTrue(req.full_url.endswith("/api/chat"))
        self.assertEqual(sent["model"], "gemma3:4b")
        self.assertEqual(sent["format"], extract.SCHEMA)
        self.assertEqual(sent["options"]["temperature"], 0)
        self.assertEqual(o.items[0].product, "Rice")

    def test_server_down_gives_helpful_error(self):
        with mock.patch("urllib.request.urlopen", side_effect=OSError("refused")):
            with self.assertRaises(extract.ExtractError) as cm:
                extract.OllamaExtractor().extract("Ravi", [Message("Ravi", "x")], catalog())
        self.assertIn("ollama pull", str(cm.exception))


if __name__ == "__main__":
    unittest.main()
