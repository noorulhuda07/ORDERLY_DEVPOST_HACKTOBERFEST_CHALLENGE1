"""Completeness check: did the extractor DROP something the customer asked for?

validate.py can only judge the lines the model returned; an item that silently disappeared leaves no line to
judge. This module looks at the customer's own words with plain code, independently of the model, and raises
a warning (-> NEEDS_REVIEW) whenever the text suggests more items than the lines account for. Two signals:

  1. a catalog product (name or alias, Telugu or English) appears in the text but no line covers it;
  2. the text contains more "item-like" segments (a quantity plus a unit or a product word, split at commas,
     full stops, "and", "also", "plus", "&", "+", newlines) than there are lines.

This cannot PROVE completeness (see README): a product the catalog does not know, written without a unit or
separator, looks like ordinary words. It errs on the side of asking: unrelated numbers without a unit or
product word (times, house numbers, phone numbers) are ignored, but a product merely named in unrelated text
("I don't need sugar") is reported.
"""
import re
from typing import Dict, List, Optional, Set

from .catalog import Catalog, norm
from .units import NUMBER_WORDS, SEGMENT_SPLIT, normalize_unit
from .validate import OrderLine, _product_words

_SPLIT = SEGMENT_SPLIT
_NOT_A_UNIT = {"no"}            # 'no' is a unit alias (nos) but in chats it means "no, not that"


def _tokens(text: str) -> List[str]:
    return norm(text).split()


def _index(catalog: Catalog) -> Dict[str, Set[str]]:
    idx: Dict[str, Set[str]] = {}
    for p in catalog.products:
        for n in p.names:
            k = norm(n)
            if k:
                idx.setdefault(k, set()).add(p.id)
    return idx


def _products_in(tokens: List[str], idx: Dict[str, Set[str]]) -> Set[str]:
    found: Set[str] = set()
    for n in range(1, 5):
        for i in range(len(tokens) - n + 1):
            found |= idx.get(" ".join(tokens[i:i + n]), set())
    return found


def _item_segments(text: str, idx: Dict[str, Set[str]]) -> int:
    count = 0
    for seg in _SPLIT.split((text or "").lower()):
        toks = _tokens(seg)
        if not toks:
            continue
        has_qty = any(ch.isdigit() for ch in seg) or any(t in NUMBER_WORDS for t in toks)
        has_unit = any(t not in _NOT_A_UNIT and normalize_unit(re.sub(r"^\d+", "", t)) for t in toks)
        if has_qty and (has_unit or _products_in(toks, idx)):
            count += 1
    return count


def _covered(lines: List[OrderLine], catalog: Catalog) -> Set[str]:
    ids: Set[str] = set()
    for l in lines:
        if l.product_id:
            ids.add(l.product_id)
        m = catalog.match(_product_words(l.raw))     # ambiguous lines cover every candidate
        if m.product:
            ids.add(m.product.id)
        ids |= {p.id for p in m.candidates}
    return ids


def omission_warning(texts: List[str], lines: List[OrderLine], catalog: Catalog) -> Optional[str]:
    """None if nothing suggests a missing item. (With zero lines pipeline already warns "No items found".)"""
    if not lines:
        return None
    idx = _index(catalog)
    mentioned: Set[str] = set()
    segments = 0
    for t in texts:
        mentioned |= _products_in(_tokens(t), idx)
        segments += _item_segments(t, idx)
    names = {p.id: p.name for p in catalog.products}
    missing = sorted(names[i] for i in mentioned - _covered(lines, catalog))
    reasons = []
    if missing:
        reasons.append("the messages mention " + ", ".join(missing) + " but no line was made for it")
    if segments > len(lines):
        reasons.append(f"the messages look like {segments} item(s) but only {len(lines)} line(s) were read")
    if not reasons:
        return None
    return "Possible missing item(s): " + "; ".join(reasons) + ". Check the customer's messages before confirming."
