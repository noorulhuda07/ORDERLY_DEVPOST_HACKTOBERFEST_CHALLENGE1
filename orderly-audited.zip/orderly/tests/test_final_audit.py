"""Regression tests from the final false-confirmation audit. Each one failed (reached CONFIRMED) before the fixes."""
import unittest

from fakes import FakeExtractor, item
from helpers import catalog
from orderly.chat import Message
from orderly.extract import RawOrder
from orderly.pipeline import build_order

C = catalog()


def run(texts, *items, voice=()):
    texts = [texts] if isinstance(texts, str) else texts
    ms = [Message("Cust", t, voice=i in voice) for i, t in enumerate(texts)]
    return build_order("Cust", ms, C, FakeExtractor(default=RawOrder(None, list(items))))


RICE2 = item("rice", "Rice", 2, "kg")
SUGAR1 = item("sugar", "Sugar", 1, "kg")


class BindingTests(unittest.TestCase):
    def test_swapped_quantities_between_products_are_not_confirmed(self):
        o = run("2 kg rice, 5 kg sugar", item("rice", "Rice", 5, "kg"), item("sugar", "Sugar", 2, "kg"))
        self.assertEqual(o.status, "NEEDS_REVIEW")

    def test_quantity_borrowed_from_another_product_is_not_confirmed(self):
        o = run("2 kg rice, 5 kg sugar", item("rice", "Rice", 5, "kg"), item("sugar", "Sugar", 5, "kg"))
        self.assertEqual(o.status, "NEEDS_REVIEW")

    def test_clock_time_is_not_a_quantity(self):
        self.assertEqual(run("send rice kg by 5:30", item("rice", "Rice", 5, "kg")).status, "NEEDS_REVIEW")

    def test_product_and_quantity_in_separate_messages_fail_closed(self):
        self.assertEqual(run(["rice", "2 kg"], RICE2).status, "NEEDS_REVIEW")

    def test_correct_binding_still_confirms(self):
        self.assertEqual(run("2 kg rice, 1 kg sugar", RICE2, SUGAR1).status, "CONFIRMED")


class CancellationTests(unittest.TestCase):
    def test_cancellations_without_the_old_cue_words_need_review(self):
        for second in ["rice vaddu", "don't want rice", "dont send rice", "leave the rice", "skip rice",
                       "rice ledu", "biyyam avasaram ledu", "3 only"]:
            o = run(["2 kg rice, 1 kg sugar", second], RICE2, SUGAR1)
            self.assertEqual(o.status, "NEEDS_REVIEW", second)

    def test_make_it_without_a_unit(self):
        self.assertEqual(run(["5 kg sugar", "make it 3"], item("sugar", "Sugar", 3, "kg")).status, "NEEDS_REVIEW")


class VoiceTests(unittest.TestCase):
    def test_wording_stitched_across_a_voice_note_and_a_text_needs_review(self):
        o = run(["rice", "2 kg"], item("rice 2 kg", "Rice", 2, "kg"), voice=(0,))
        self.assertEqual(o.status, "NEEDS_REVIEW")

    def test_plain_voice_line_still_needs_confirmation(self):
        self.assertEqual(run(["[voice note] 2 kg rice"], RICE2).status, "NEEDS_REVIEW")


class HardeningTests(unittest.TestCase):
    def test_unrecognised_export_with_dotted_times_is_refused_not_merged_into_one_customer(self):
        from orderly.chat import parse_input
        with self.assertRaises(ValueError):
            parse_input("9.13 pm - Bob: 2 kg sugar\n9.14 pm - Anna: 5 kg rice")

    def test_infinite_price_or_max_qty_is_rejected_at_load(self):
        from orderly.catalog import Catalog
        for p in ({"price": float("inf")}, {"price": 1, "max_qty": float("inf")}, {"variants": {"1l": float("inf")}}):
            with self.assertRaises(ValueError):
                Catalog.from_dict({"products": [{"id": "a", "name": "A", **p}]})


class EvalIntegrityTests(unittest.TestCase):
    def test_eval_counts_swapped_quantities_as_false_confirmations(self):
        from orderly import evaluate
        ex = FakeExtractor(default=RawOrder(None, [item("rice", "Rice", 5, "kg"), item("sugar", "Sugar", 2, "kg")]))
        cases = [{"messages": ["2 kg rice, 5 kg sugar"], "expected": [{"product": "rice", "quantity": 2},
                  {"product": "sugar", "quantity": 5}], "expected_flags": []}]
        r = evaluate.run_eval(cases, C, ex)
        self.assertEqual(r.false_confirmations, 0)       # binding now blocks them, so nothing is confirmed ...
        self.assertEqual(r.confirmed_items, 0)           # ... and the eval would have counted any that slipped through


class StatusEvalTests(unittest.TestCase):
    """The evaluation's pass/fail rules: one expected status per case, decided from the ORIGINAL message."""

    def ev(self, case, *items, exc=None):
        from orderly import evaluate
        if exc:
            class Boom(FakeExtractor):
                def extract(self, *a):
                    raise exc
            ex = Boom()
        else:
            ex = FakeExtractor(default=RawOrder(None, list(items)))
        return evaluate.run_eval([case], C, ex)

    def case(self, msgs, status, expected, **kw):
        return {"messages": msgs, "expected": expected, "expected_flags": [], "expected_status": status, **kw}

    def test_valid_order_confirmed_correctly_passes(self):
        r = self.ev(self.case(["2 kg rice"], "CONFIRMED", [{"product": "rice", "quantity": 2}]), RICE2)
        self.assertEqual((r.correctly_confirmed, r.false_rejections, r.p0), (1, 0, []))

    def test_valid_order_rejected_is_a_usability_failure_not_a_safety_failure(self):
        r = self.ev(self.case(["rice kuda"], "CONFIRMED", [{"product": "rice", "quantity": 2}]), RICE2)
        self.assertEqual((r.false_rejections, r.false_confirmed_cases, r.p0), (1, 0, []))
        self.assertEqual(r.p0_count, 0)

    def test_unsafe_case_blocked_passes(self):
        r = self.ev(self.case(["2 kg rice and 1 kg sugar"], "NEEDS_REVIEW",
                              [{"product": "rice", "quantity": 2}, {"product": "sugar", "quantity": 1}]), RICE2)
        self.assertEqual((r.correctly_blocked, r.false_confirmed_cases), (1, 0))

    def test_needs_review_case_that_confirms_is_a_p0_and_makes_the_audit_incomplete(self):
        from orderly import evaluate
        # the known open limit (unknown product, no unit): the eval must SHOW it as a P0, never hide it
        r = self.ev(self.case(["2 kg rice, 3 bellam"], "NEEDS_REVIEW", [{"product": "rice", "quantity": 2}]), RICE2)
        self.assertEqual((r.false_confirmed_cases, r.case_false_confirmation_rate), (1, 1.0))
        self.assertEqual(r.p0_count, 1)
        self.assertIn("FALSE CONFIRMATION", r.p0[0])

    def test_confirmed_with_the_wrong_content_is_never_a_pass_even_if_the_status_matches(self):
        r = self.ev(self.case(["2 kg rice oka bellam"], "CONFIRMED",
                              [{"product": "rice", "quantity": 2}, {"product": "bellam", "quantity": 1}]), RICE2)
        self.assertEqual((r.correctly_confirmed, r.wrong_confirmed_cases), (0, 1))
        self.assertEqual(r.p0_count, 1)

    def test_extra_unrequested_confirmed_item_is_wrong(self):
        r = self.ev(self.case(["2 kg rice"], "CONFIRMED", [{"product": "rice", "quantity": 2}]), RICE2, item("rice", "Rice", 2, "kg"))
        self.assertEqual(r.correctly_confirmed, 0)

    def test_exception_is_an_execution_failure_that_cannot_confirm(self):
        from orderly.extract import ExtractError
        r = self.ev(self.case(["2 kg rice"], "CONFIRMED", [{"product": "rice", "quantity": 2}]), exc=ExtractError("down"))
        self.assertEqual((r.execution_failures, r.correctly_confirmed, r.false_confirmed_cases), (1, 0, 0))

    def test_voice_cases_never_confirm(self):
        r = self.ev(self.case(["2 kg rice"], "NEEDS_REVIEW", [{"product": "rice", "quantity": 2}], voice=[0]), RICE2)
        self.assertEqual((r.correctly_blocked, r.false_confirmed_cases), (1, 0))

    def test_shipped_cases_all_declare_exactly_one_valid_status(self):
        import os
        from helpers import ROOT
        from orderly import evaluate
        cases = evaluate.load_cases(os.path.join(ROOT, "data", "eval_cases.jsonl"))
        self.assertTrue(all(c["expected_status"] in ("CONFIRMED", "NEEDS_REVIEW") for c in cases))

    def test_a_case_without_or_with_an_invented_status_is_rejected_at_load(self):
        import json, tempfile, os
        from orderly import evaluate
        for bad in ({"messages": ["x"]}, {"messages": ["x"], "expected_status": "PARTIAL"},
                    {"messages": ["x"], "expected_status": "confirmed"}):
            with tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False, encoding="utf-8") as f:
                f.write(json.dumps(bad) + "\n")
            try:
                with self.assertRaises(ValueError):
                    evaluate.load_cases(f.name)
            finally:
                os.unlink(f.name)


if __name__ == "__main__":
    unittest.main()


class AuditStatusVsReadinessTests(unittest.TestCase):
    """AUDIT STATUS (may the audit continue) and READINESS (may it be used) are two fields; P1 never stops the audit."""
    GOOD = {"available": True, "provenance": "VERIFIED", "detail": ""}

    def res(self, **kw):
        from orderly.evaluate import EvalResult
        kw.setdefault("cases", 1)
        return EvalResult(**kw)

    def audit(self, res, probe=None):
        from orderly import evaluate
        return evaluate.audit_result(res, probe or self.GOOD, "NO")

    def test_real_model_unavailable_stops_and_readiness_is_not_assessed(self):
        a = self.audit(self.res(cases=0), {"available": False, "provenance": "NOT VERIFIED", "detail": "x"})
        self.assertEqual((a["status"], a["readiness"], a["gemma"]), ("STOPPED - REAL MODEL UNAVAILABLE", "NOT ASSESSED", "NO"))
        from orderly import evaluate
        self.assertIn("P0 false confirmations: NOT TESTED", evaluate.render_audit_result(a))   # never a misleading "0"

    def test_unverified_provenance_stops(self):
        a = self.audit(self.res(), {"available": True, "provenance": "NOT VERIFIED", "detail": "x"})
        self.assertEqual((a["status"], a["readiness"]), ("STOPPED - PROVENANCE UNVERIFIED", "NOT ASSESSED"))

    def test_demonstrated_p0_stops_and_is_not_ready(self):
        a = self.audit(self.res(false_confirmed_cases=1))
        self.assertEqual((a["status"], a["readiness"], a["p0"]), ("STOPPED - P0 FALSE CONFIRMATION FOUND", "NOT READY", 1))

    def test_p1_alone_completes_the_audit_but_caps_readiness(self):
        a = self.audit(self.res())
        self.assertEqual(a["status"], "COMPLETED")
        self.assertEqual((a["p0"], a["p1"]), (0, 1))
        self.assertEqual(a["readiness"], "DEMO / CONTROLLED HUMAN REVIEW ONLY - KNOWN P1 LIMITATION")

    def test_partially_verified_provenance_still_completes(self):
        a = self.audit(self.res(), {"available": True, "provenance": "PARTIALLY VERIFIED", "detail": ""})
        self.assertEqual((a["status"], a["provenance"]), ("COMPLETED", "PARTIALLY VERIFIED"))

    def test_unexecuted_cases_never_yield_a_completed_audit(self):
        self.assertTrue(self.audit(self.res(execution_failures=2))["status"].startswith("STOPPED"))

    def test_no_p0_and_no_p1_is_the_only_way_to_reach_READY(self):
        from unittest import mock
        from orderly import evaluate
        with mock.patch.object(evaluate, "KNOWN_P1", []):
            self.assertEqual(self.audit(self.res())["readiness"], "DEMO / CONTROLLED HUMAN REVIEW READY")

    def test_report_block_has_the_exact_fields(self):
        from orderly import evaluate
        txt = evaluate.render_audit_result(self.audit(self.res()))
        for line in ("AUDIT RESULT", "Real Gemma available: YES", "Model provenance: VERIFIED", "Real Whisper tested: NO",
                     "P0 false confirmations: 0", "P1 limitations: 1", "AUDIT STATUS:", "READINESS VERDICT:",
                     "Code modified during evaluation: NO"):
            self.assertIn(line, txt)

    def test_probe_unreachable_ollama_is_unavailable_not_a_crash(self):
        from orderly import evaluate
        def boom(*a, **k):
            raise OSError("refused")
        p = evaluate.probe_model("gemma3:4b", "http://localhost:1", opener=boom)
        self.assertEqual((p["available"], p["provenance"]), (False, "NOT VERIFIED"))

    def test_probe_provenance_levels(self):
        import io, json as j
        from orderly import evaluate
        def opener(models):
            return lambda url, timeout=0: io.BytesIO(j.dumps({"models": models}).encode())
        m = {"name": "gemma3:4b", "digest": "sha256:abcdef123456", "details": {"family": "gemma3"}}
        self.assertEqual(evaluate.probe_model("gemma3:4b", "h", None, opener([m]))["provenance"], "PARTIALLY VERIFIED")
        self.assertEqual(evaluate.probe_model("gemma3:4b", "h", "abcdef", opener([m]))["provenance"], "VERIFIED")
        self.assertEqual(evaluate.probe_model("gemma3:4b", "h", "ffffff", opener([m]))["provenance"], "NOT VERIFIED")
        other = dict(m, details={"family": "llama"})
        self.assertEqual(evaluate.probe_model("gemma3:4b", "h", "abcdef", opener([other]))["provenance"], "NOT VERIFIED")
        self.assertFalse(evaluate.probe_model("gemma3:4b", "h", None, opener([]))["available"])


if __name__ == "__main__":
    unittest.main()
