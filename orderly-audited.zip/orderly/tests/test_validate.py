import unittest

from fakes import item
from helpers import catalog
from orderly.validate import validate_item


def codes(line):
    return [f.code for f in line.flags]


class ValidateTests(unittest.TestCase):
    def setUp(self):
        self.c = catalog()

    def v(self, *a, **k):
        return validate_item(item(*a, **k), self.c)

    def test_clean_line_gets_price(self):
        l = self.v("biyyam", "Rice", 2, "kg")
        self.assertEqual((l.status, l.product_id, l.quantity, l.unit, l.total), ("ok", "rice", 2, "kg", 124.0))

    def test_grams_convert_to_kg(self):
        l = self.v("pappu", "Toor Dal", 500, "g")
        self.assertEqual((l.quantity, l.total), (0.5, 75.0))

    def test_dozen_eggs(self):
        l = self.v("gudlu", "Eggs", 1, "dozen")
        self.assertEqual((l.quantity, l.unit, l.total), (12, "pcs", 84.0))

    def test_count_item_without_unit_assumes_base(self):
        self.assertEqual(self.v("sabbu", "Bath Soap", 2).total, 76.0)

    def test_weight_item_without_unit_is_flagged(self):
        self.assertEqual(codes(self.v("sugar", "Sugar", 3)), ["missing_unit"])

    def test_missing_quantity_and_zero(self):
        self.assertEqual(codes(self.v("sugar", "Sugar", None, "kg")), ["missing_quantity"])
        self.assertEqual(codes(self.v("sugar", "Sugar", 0, "kg")), ["missing_quantity"])

    def test_missing_size_asks_in_both_languages(self):
        l = self.v("karam", "Chilli Powder", 1, "packet")
        self.assertEqual(codes(l), ["missing_size"])
        self.assertIn("which size", l.flags[0].question_en)
        self.assertIn("సైజ్", l.flags[0].question_te)
        self.assertIsNone(l.total)

    def test_size_given_prices_the_variant(self):
        l = self.v("karam", "Chilli Powder", 2, None, "250 g")
        self.assertEqual((l.status, l.size, l.total), ("ok", "250g", 210.0))

    def test_litre_in_quantity_becomes_size(self):
        l = self.v("sunflower oil", "Sunflower Oil", 1, "litre")
        self.assertEqual((l.status, l.size, l.quantity, l.total), ("ok", "1l", 1, 180.0))

    def test_unsold_size(self):
        self.assertEqual(codes(self.v("sunflower oil", "Sunflower Oil", 300, "ml")), ["bad_size"])
        self.assertEqual(codes(self.v("sunflower oil", "Sunflower Oil", 1, None, "2l")), ["bad_size"])

    def test_ambiguous_and_unknown(self):
        a = self.v("oil", "oil", 1, "litre")
        self.assertEqual(codes(a), ["ambiguous_product"])
        self.assertIn("Sunflower Oil or Groundnut Oil", a.flags[0].question_en)
        u = self.v("laptop", "laptop", 1)
        self.assertEqual((codes(u), u.product_id), (["unknown_product"], None))

    def test_model_cannot_invent_a_catalog_product(self):
        l = self.v("biyyam", "Basmati Premium Rice 10kg", 1, "kg")   # model hallucinated a name
        self.assertEqual(l.product_id, "rice")                      # falls back to customer's own word

    def test_bad_unit(self):
        self.assertEqual(codes(self.v("rice", "Rice", 2, "litre")), ["bad_unit"])
        # an unrecognised unit is "not understood", never silently treated as "no unit" (see test_safety)
        self.assertEqual(codes(self.v("rice", "Rice", 2, "bucket")), ["bad_unit"])

    def test_large_quantity(self):
        self.assertEqual(codes(self.v("rice", "Rice", 500, "kg")), ["large_quantity"])

    def test_fuzzy_match_asks_to_confirm(self):
        l = self.v("biyam", "biyam", 1, "kg")
        self.assertEqual((codes(l), l.product_id), (["confirm_product"], "rice"))
        self.assertIsNone(l.total)


if __name__ == "__main__":
    unittest.main()
