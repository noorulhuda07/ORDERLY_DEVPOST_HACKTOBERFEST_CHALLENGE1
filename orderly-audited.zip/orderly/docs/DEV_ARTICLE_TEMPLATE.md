# DEV article skeleton (fill in YOUR real details; do not publish the [brackets])

Title idea: **I built a WhatsApp order-taker for [relative]'s shop with local open-source AI**

## What I built
- Who: [relative's name or relationship], who runs [type of shop] in [town]
- The problem, in their words: [what happens every day: how many orders, how messy, what goes wrong]
- What Orderly does: voice notes + Telugu/English texts to a verified order list; asks "which size?" when unsure

## Demo
- [video link, 90 seconds: messy message and voice note in, clean list and suggested reply out]
- [screenshot of the web UI]

## How I built it
- Whisper (faster-whisper) for voice, Gemma 3 via Ollama for extraction, Python code for validation
- Architecture: model reads, code decides (catalog check, sizes, units, price, flags)
- [what went wrong first and how you fixed it]

## Did it work? (real numbers)
- Ran `orderly eval` on [N] real messages: item precision [x]%, recall [y]%, flags caught [z]%
- Time per order before vs after: [measure it]
- What [relative] said when they tried it: "[their actual words]"

## Why open-source AI mattered
- Privacy: customers' messages stay on the shop computer
- Cost: no per-message API bill
- Control: catalog words feed both models; models are swappable
- What I would change if I could only use a closed API: [honest answer]

## What I learned / what's next
- [real limits you hit, e.g. Telugu voice accuracy by model size]
