"""Tiny local web UI (standard library only). Binds to 127.0.0.1: your customers' messages stay on this machine."""
import json
import os
import tempfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote

from . import report
from .chat import UNCLEAR, parse_input
from .extract import ExtractError
from .pipeline import process
from .transcribe import TranscribeError

PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Orderly</title>
<style>
:root{--bg:#fafaf7;--fg:#1d1d1b;--mut:#6b6b66;--card:#fff;--line:#e4e2da;--ok:#1a7f4b;--ask:#b45309;--acc:#1f4fd8}
@media(prefers-color-scheme:dark){:root{--bg:#161614;--fg:#eeeee9;--mut:#a3a39b;--card:#1f1f1c;--line:#34342f;--ok:#4ade80;--ask:#fbbf24;--acc:#7aa2ff}}
*{box-sizing:border-box}body{margin:0;font:16px/1.5 system-ui,sans-serif;background:var(--bg);color:var(--fg);max-width:820px;margin:auto;padding:20px}
h1{margin:0 0 4px}.sub{color:var(--mut);margin:0 0 16px}
textarea{width:100%;min-height:150px;padding:12px;border:1px solid var(--line);border-radius:10px;background:var(--card);color:var(--fg);font:inherit}
.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:10px 0 18px}
button,.file{background:var(--acc);color:#fff;border:0;border-radius:10px;padding:10px 16px;font:inherit;cursor:pointer}
.file{background:transparent;color:var(--acc);border:1px solid var(--acc)}.file input{display:none}
#status{color:var(--mut)}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px 16px;margin-bottom:16px}
.card h2{margin:0 0 8px;font-size:1.1rem}
table{width:100%;border-collapse:collapse}td,th{padding:6px 4px;text-align:left;border-bottom:1px solid var(--line);vertical-align:top}
.ok{color:var(--ok)}.ask{color:var(--ask)}.why{color:var(--mut);font-size:.9rem}
.warn{background:rgba(180,83,9,.12);border-radius:8px;padding:8px 10px;margin:8px 0}
pre{white-space:pre-wrap;background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:10px;font:inherit}
.total{margin-top:8px;font-weight:600}
</style></head><body>
<h1>Orderly</h1>
<p class="sub">Messy WhatsApp orders in Telugu and English become a clean list. Runs on this computer; nothing goes to the cloud.</p>
<textarea id="msgs" placeholder="Paste customer messages here, one per line (or a WhatsApp chat export)"></textarea>
<div class="row"><button id="go">Make order list</button>
<label class="file">Add a voice note<input type="file" id="audio" accept="audio/*,.opus,.ogg"></label><span id="status"></span></div>
<div id="out"></div>
<script>
const $=id=>document.getElementById(id);
function el(t,a,...k){const e=document.createElement(t);for(const[x,v]of Object.entries(a||{})){x==='class'?e.className=v:e.setAttribute(x,v)}
for(const c of k){e.append(c instanceof Node?c:document.createTextNode(String(c)))}return e}
function qty(l){if(l.quantity==null)return'?';return(Number.isInteger(l.quantity)?l.quantity:+l.quantity.toFixed(3))+' '+(l.unit||'')}
function render(orders){const out=$('out');out.replaceChildren();
for(const o of orders){const card=el('div',{class:'card'},el('h2',{},o.customer));
const tb=el('table',{},el('tr',{},el('th',{},'Item'),el('th',{},'Qty'),el('th',{},'Price'),el('th',{},'')));
for(const l of o.lines){const ok=l.status==='ok';
const name=(l.product_name||('? '+l.raw))+(l.size?' ['+l.size+']':'');
const why=l.flags.map(f=>f.message).join('; ');
tb.append(el('tr',{},el('td',{},name,why?el('div',{class:'why'},why):''),el('td',{},qty(l)),
el('td',{},l.total!=null?o.currency+l.total:''),el('td',{class:ok?'ok':'ask'},ok?'OK':'ASK')))}
card.append(tb);
card.append(el('div',{class:'total'},(o.status==='CONFIRMED'?'READY. ':'NEEDS REVIEW. ')+'Confirmed total: '+o.currency+o.confirmed_total+'  ('+o.needs_reply+' line(s) need a reply)'));
if(o.notes)card.append(el('div',{class:'why'},'Note: '+o.notes));
for(const w of o.warnings)card.append(el('div',{class:'warn'},w));
if(o.reply){const pre=el('pre',{},o.reply);const b=el('button',{},'Copy reply');
b.onclick=()=>{navigator.clipboard.writeText(o.reply);b.textContent='Copied'};card.append(el('div',{class:'why'},'Suggested reply to customer:'),pre,b)}
out.append(card)}}
$('go').onclick=async()=>{const s=$('status');s.textContent='Reading messages...';
try{const r=await fetch('/api/process',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:$('msgs').value})});
const d=await r.json();if(!r.ok)throw new Error(d.error||'failed');render(d.orders);s.textContent=''}catch(e){s.textContent='Error: '+e.message}};
$('audio').onchange=async ev=>{const f=ev.target.files[0];if(!f)return;const s=$('status');s.textContent='Listening to voice note...';
try{const r=await fetch('/api/transcribe',{method:'POST',headers:{'X-Filename':encodeURIComponent(f.name)},body:f});
const d=await r.json();if(!r.ok)throw new Error(d.error||'failed');
const t=$('msgs');t.value+=(t.value&&!t.value.endsWith('\\n')?'\\n':'')+'[voice note] '+d.text+'\\n';s.textContent='Voice note added below. Check it, then press Make order list.'}
catch(e){s.textContent='Error: '+e.message}ev.target.value=''};
</script></body></html>"""


LOOPBACK = ("127.0.0.1", "localhost", "::1")


def make_server(catalog, extractor, transcriber=None, host="127.0.0.1", port=8000):
    class Handler(BaseHTTPRequestHandler):
        def _host_ok(self):
            """Bound to loopback: refuse requests whose Host is not loopback (DNS-rebinding protection)."""
            if host not in LOOPBACK:
                return True
            h = (self.headers.get("Host") or "").strip().lower()
            h = h[1:h.index("]")] if h.startswith("[") and "]" in h else h.rsplit(":", 1)[0]
            return h in LOOPBACK

        def _send(self, code, payload, ctype="application/json"):
            body = payload.encode("utf-8") if isinstance(payload, str) else payload
            self.send_response(code)
            self.send_header("Content-Type", ctype + "; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _err(self, code, msg):
            self._send(code, json.dumps({"error": msg}, ensure_ascii=False))

        def do_GET(self):
            if not self._host_ok():
                return self._err(403, "forbidden host")
            if self.path in ("/", "/index.html"):
                self._send(200, PAGE, "text/html")
            else:
                self._err(404, "not found")

        def do_POST(self):
            if not self._host_ok():
                return self._err(403, "forbidden host")
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                return self._err(400, "bad Content-Length")
            if n < 0:
                return self._err(400, "bad Content-Length")
            if n > 50_000_000:
                return self._err(413, "file too large")
            ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            if self.path == "/api/process" and ctype != "application/json":
                return self._err(415, "send application/json")
            if self.path == "/api/transcribe" and not self.headers.get("X-Filename"):
                return self._err(400, "X-Filename header required")
            data = self.rfile.read(n)
            try:
                if self.path == "/api/process":
                    body = json.loads(data or b"{}")
                    text = body.get("text", "") if isinstance(body, dict) else None
                    if not isinstance(text, str):
                        return self._err(400, "text must be a string")
                    orders = process(parse_input(text), catalog, extractor)
                    return self._send(200, json.dumps(
                        {"orders": [report.to_dict(o, catalog.currency) for o in orders]}, ensure_ascii=False))
                if self.path == "/api/transcribe":
                    if transcriber is None:
                        return self._err(501, "voice notes are not enabled (install faster-whisper)")
                    name = os.path.basename(unquote(self.headers.get("X-Filename", "")))
                    if name in ("", ".", ".."):
                        name = "voice.opus"
                    with tempfile.TemporaryDirectory(prefix="orderly-") as d:
                        path = os.path.join(d, name)
                        with open(path, "wb") as f:
                            f.write(data)
                        text, low = transcriber.transcribe(path)
                    return self._send(200, json.dumps({"text": f"{text} {UNCLEAR}" if low or not text else text,
                                                       "voice": True}, ensure_ascii=False))
                self._err(404, "not found")
            except (ExtractError, TranscribeError) as e:
                self._err(502, str(e))
            except ValueError:                      # bad JSON, bad UTF-8, unsupported chat export format
                self._err(400, "bad request")
            except Exception:                       # never leak internals to the browser
                self._err(500, "internal error")

        def log_message(self, *a):  # keep the terminal quiet
            pass

    return ThreadingHTTPServer((host, port), Handler)
